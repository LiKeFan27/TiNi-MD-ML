import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

# =========================
# PATH
# =========================
DATA_PATH = r"E:\TiNi_4_code\Dataset.xlsx"
OUT_DIR = Path(r"E:\TiNi_4_code\results_feature_analysis_final")
OUT_DIR.mkdir(parents=True, exist_ok=True)

# =========================
# COLUMN MAP
# =========================
COLUMN_MAP = {
    "d_min (nm)": "dmin",
    "d_max (nm)": "dmax",
    "GB_frac0": "fGB",
    "Max Strain(%)": "emax",
    "T (K)": "T",
    "cycle_n": "N",
    "Load_Status": "Sload",
    "Davg": "davg",
    "Current_Strain": "et",
    "Current_Stress": "st"
}

# =========================
# FEATURES
# =========================
STRUCTURE_FEATURES = ["dmin", "dmax", "gd", "fGB", "davg"]

ALL_FEATURES = [
    "dmin", "dmax", "gd", "fGB", "davg",
    "emax", "T", "N", "Sload", "et"
]

TARGET = "st"


# =========================
# LOAD DATA
# =========================
def load_data():
    df = pd.read_excel(DATA_PATH, engine="openpyxl")
    df = df.rename(columns=COLUMN_MAP)

    # numeric
    for c in ALL_FEATURES + [TARGET]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")

    df = df.dropna(subset=ALL_FEATURES + [TARGET]).reset_index(drop=True)

    print("Rows:", len(df))
    print("Columns:", df.columns.tolist())

    return df


# =========================
# OUTPUT DATA (IMPORTANT FOR PAPER)
# =========================
def export_data(df):
    # Fig A data
    corr_structure = df[STRUCTURE_FEATURES].corr()
    corr_structure.to_csv(OUT_DIR / "structure_pearson.csv")

    # Fig B data
    corr_target = df[ALL_FEATURES].corrwith(df[TARGET])
    corr_target = corr_target.sort_values()
    corr_target.to_csv(OUT_DIR / "feature_stress_corr.csv")

    print("CSV exported.")


# =========================
# FIG A: STRUCTURE PEARSON
# =========================
def plot_structure(ax, df):
    corr = df[STRUCTURE_FEATURES].corr()

    im = ax.imshow(corr.values, cmap="RdBu_r", vmin=-1, vmax=1)

    ax.set_xticks(range(len(STRUCTURE_FEATURES)))
    ax.set_yticks(range(len(STRUCTURE_FEATURES)))
    ax.set_xticklabels(STRUCTURE_FEATURES, rotation=45, ha="right")
    ax.set_yticklabels(STRUCTURE_FEATURES)

    ax.set_title("(a) Structure-only Pearson")

    # 只标强相关
    for i in range(len(STRUCTURE_FEATURES)):
        for j in range(len(STRUCTURE_FEATURES)):
            v = corr.iloc[i, j]
            if abs(v) > 0.5:
                ax.text(j, i, f"{v:.2f}",
                        ha="center", va="center",
                        fontsize=8, color="white")

    return im


# =========================
# FIG B: FEATURE → STRESS
# =========================
def plot_feature_stress(ax, df):
    corr = df[ALL_FEATURES].corrwith(df[TARGET])

    corr = corr.sort_values()

    bars = ax.barh(corr.index, corr.values, color="#2F6B9A")

    ax.set_title("(b) Feature–Stress correlation")
    ax.set_xlabel("Pearson r")
    ax.grid(True, linestyle="--", alpha=0.3)

    # 标数值
    for bar, v in zip(bars, corr.values):
        ax.text(v, bar.get_y() + bar.get_height()/2,
                f"{v:.2f}",
                va="center", fontsize=8)


# =========================
# MAIN
# =========================
def main():
    df = load_data()

    # export data for paper reproducibility
    export_data(df)

    # plotting
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))

    im = plot_structure(axes[0], df)
    plt.colorbar(im, ax=axes[0], fraction=0.046)

    plot_feature_stress(axes[1], df)

    plt.tight_layout()

    out_png = OUT_DIR / "Fig_feature_analysis.png"
    out_pdf = OUT_DIR / "Fig_feature_analysis.pdf"

    plt.savefig(out_png, dpi=600, bbox_inches="tight")
    plt.savefig(out_pdf, bbox_inches="tight")

    plt.close()

    print("Saved:", out_png)


if __name__ == "__main__":
    main()