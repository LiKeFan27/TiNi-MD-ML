# -*- coding: utf-8 -*-
"""
04_calc_gru_groupkfold_metrics_third_style.py

功能：
    从 third-paper style GroupKFold GRU 预测结果中提取循环性能指标。

输入：
    E:\TiNi_4_code\gru_oof_results_10features_third_style\predictions\gru_oof_predictions_all.xlsx

输出：
    E:\TiNi_4_code\gru_groupkfold_metrics_10features_third_style\
        gru_groupkfold_cyclic_descriptors.xlsx
        figures\

计算指标：
    sigma_max
    epsilon_res
    DeltaW
    R_sigma
    R_W
    Delta_epsilon_res
    FSI_final_state
    FSI_degradation
    FSI_mean

说明：
    该脚本不会重新训练模型。
    它只读取已经预测好的 Current_Stress_true 和 Current_Stress_pred，
    然后分别从真实曲线和预测曲线中提取循环性能指标。
"""

from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error


# =========================================================
# 1. 路径设置
# =========================================================

BASE_DIR = Path(r"E:\TiNi_4_code")

OOF_PATH = (
    BASE_DIR
    / "gru_oof_results_10features_third_style"
    / "predictions"
    / "gru_oof_predictions_all.xlsx"
)

OUTPUT_DIR = BASE_DIR / "gru_groupkfold_metrics_10features_third_style"
FIG_DIR = OUTPUT_DIR / "figures"

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
FIG_DIR.mkdir(parents=True, exist_ok=True)

OUTPUT_EXCEL = OUTPUT_DIR / "gru_groupkfold_cyclic_descriptors.xlsx"

if not OOF_PATH.exists():
    raise FileNotFoundError(
        f"\n找不到 GroupKFold 预测文件：\n{OOF_PATH}\n\n"
        "请先确认已经完成 third-paper style GroupKFold 训练，并且存在：\n"
        r"E:\TiNi_4_code\gru_oof_results_10features_third_style\predictions\gru_oof_predictions_all.xlsx"
    )


# =========================================================
# 2. 列名设置
# =========================================================

COL_ID = "ID"

COL_DMIN = "d_min (nm)"
COL_DMAX = "d_max (nm)"
COL_DAVG = "Davg"
COL_GD = "gd"
COL_GB = "GB_frac0"

COL_EMAX = "Max Strain(%)"
COL_T = "T (K)"

COL_CYCLE = "cycle_n"
COL_STATUS = "Load_Status"
COL_STRAIN = "Current_Strain"

COL_TRUE = "Current_Stress_true"
COL_PRED = "Current_Stress_pred"

GROUP_KEYS_CYCLE = [COL_ID, COL_T, COL_EMAX, COL_CYCLE]
GROUP_KEYS_CONDITION = [COL_ID, COL_T, COL_EMAX]


# =========================================================
# 3. 工具函数
# =========================================================

def integrate_trapz(y, x):
    """兼容不同 numpy 版本的梯形积分。"""
    if hasattr(np, "trapezoid"):
        return np.trapezoid(y, x)
    return np.trapz(y, x)


def rmse(y_true, y_pred):
    return np.sqrt(mean_squared_error(y_true, y_pred))


def minmax_norm_by_ref(s, ref):
    """
    用 ref 的 min/max 对 s 归一化。
    true 和 pred 的 FSI 使用同一套尺度。
    """
    s = s.astype(float)
    ref = ref.astype(float)

    ref_min = ref.min(skipna=True)
    ref_max = ref.max(skipna=True)

    if pd.isna(ref_min) or pd.isna(ref_max):
        return pd.Series(np.nan, index=s.index)

    if ref_max == ref_min:
        return pd.Series(0.5, index=s.index)

    return (s - ref_min) / (ref_max - ref_min)


def calc_cycle_descriptors(group, stress_col):
    """
    对一个 ID + T + Max Strain + cycle_n 的完整加载-卸载路径计算：
        sigma_max
        epsilon_res
        DeltaW
    """
    group = group.sort_values("__row_order").copy()

    stress = group[stress_col].to_numpy(dtype=float)
    strain_percent = group[COL_STRAIN].to_numpy(dtype=float)
    strain_fraction = strain_percent / 100.0

    sigma_max = np.nanmax(stress)

    unload = group[group[COL_STATUS] == -1].copy()

    if len(unload) > 0:
        idx_res = unload[stress_col].abs().idxmin()
        epsilon_res = float(unload.loc[idx_res, COL_STRAIN])
        stress_at_res = float(unload.loc[idx_res, stress_col])
    else:
        epsilon_res = np.nan
        stress_at_res = np.nan

    if len(group) >= 2:
        deltaW_GPa = abs(integrate_trapz(stress, strain_fraction))
        deltaW_MJ_m3 = deltaW_GPa * 1000.0
    else:
        deltaW_MJ_m3 = np.nan

    return pd.Series({
        "sigma_max_GPa": sigma_max,
        "epsilon_res_percent": epsilon_res,
        "stress_at_epsilon_res_GPa": stress_at_res,
        "DeltaW_MJ_m3": deltaW_MJ_m3,
        "n_points": len(group),
    })


def build_descriptors(df, stress_col, suffix):
    """
    从点级应力数据构建：
        1. cycle-level descriptors
        2. ID-condition descriptors
    """
    cycle_desc = (
        df.groupby(GROUP_KEYS_CYCLE, sort=False)
        .apply(lambda g: calc_cycle_descriptors(g, stress_col))
        .reset_index()
    )

    meta_cols = [COL_DMIN, COL_DMAX, COL_GD, COL_GB]

    if COL_DAVG in df.columns:
        meta_cols.insert(2, COL_DAVG)

    meta = (
        df.groupby(GROUP_KEYS_CONDITION, sort=False)[meta_cols]
        .first()
        .reset_index()
    )

    cycle_desc = cycle_desc.merge(
        meta,
        on=GROUP_KEYS_CONDITION,
        how="left"
    )

    cycle1 = cycle_desc[cycle_desc[COL_CYCLE] == 1].set_index(GROUP_KEYS_CONDITION)
    cycle8 = cycle_desc[cycle_desc[COL_CYCLE] == 8].set_index(GROUP_KEYS_CONDITION)

    id_desc = meta.set_index(GROUP_KEYS_CONDITION).copy()

    id_desc[f"sigma_max_1_GPa_{suffix}"] = cycle1["sigma_max_GPa"]
    id_desc[f"sigma_max_8_GPa_{suffix}"] = cycle8["sigma_max_GPa"]

    id_desc[f"epsilon_res_1_percent_{suffix}"] = cycle1["epsilon_res_percent"]
    id_desc[f"epsilon_res_8_percent_{suffix}"] = cycle8["epsilon_res_percent"]

    id_desc[f"DeltaW_1_MJ_m3_{suffix}"] = cycle1["DeltaW_MJ_m3"]
    id_desc[f"DeltaW_8_MJ_m3_{suffix}"] = cycle8["DeltaW_MJ_m3"]

    id_desc[f"R_sigma_{suffix}"] = (
        id_desc[f"sigma_max_8_GPa_{suffix}"] /
        id_desc[f"sigma_max_1_GPa_{suffix}"]
    )

    id_desc[f"R_W_{suffix}"] = (
        id_desc[f"DeltaW_8_MJ_m3_{suffix}"] /
        id_desc[f"DeltaW_1_MJ_m3_{suffix}"]
    )

    id_desc[f"Delta_epsilon_res_percent_{suffix}"] = (
        id_desc[f"epsilon_res_8_percent_{suffix}"] -
        id_desc[f"epsilon_res_1_percent_{suffix}"]
    )

    id_desc = id_desc.reset_index()

    return cycle_desc, id_desc


def add_fsi_columns(df, suffix=""):
    """
    添加 FSI 指标。
    suffix = ""      -> 全数据范围 FSI
    suffix = "local" -> 当前筛选范围内 FSI，例如 400 K, 10%
    """
    tag = "" if suffix == "" else f"_{suffix}"

    out = df.copy()

    out[f"R_sigma_norm_true{tag}"] = minmax_norm_by_ref(
        out["R_sigma_true"],
        out["R_sigma_true"]
    )
    out[f"R_sigma_norm_pred{tag}"] = minmax_norm_by_ref(
        out["R_sigma_pred"],
        out["R_sigma_true"]
    )

    out[f"R_W_norm_true{tag}"] = minmax_norm_by_ref(
        out["R_W_true"],
        out["R_W_true"]
    )
    out[f"R_W_norm_pred{tag}"] = minmax_norm_by_ref(
        out["R_W_pred"],
        out["R_W_true"]
    )

    out[f"epsilon_res_8_norm_true{tag}"] = minmax_norm_by_ref(
        out["epsilon_res_8_percent_true"],
        out["epsilon_res_8_percent_true"]
    )
    out[f"epsilon_res_8_norm_pred{tag}"] = minmax_norm_by_ref(
        out["epsilon_res_8_percent_pred"],
        out["epsilon_res_8_percent_true"]
    )

    out[f"Delta_epsilon_res_norm_true{tag}"] = minmax_norm_by_ref(
        out["Delta_epsilon_res_percent_true"],
        out["Delta_epsilon_res_percent_true"]
    )
    out[f"Delta_epsilon_res_norm_pred{tag}"] = minmax_norm_by_ref(
        out["Delta_epsilon_res_percent_pred"],
        out["Delta_epsilon_res_percent_true"]
    )

    out[f"FSI_final_state_true{tag}"] = (
        out[f"R_sigma_norm_true{tag}"]
        + out[f"R_W_norm_true{tag}"]
        - out[f"epsilon_res_8_norm_true{tag}"]
    )

    out[f"FSI_final_state_pred{tag}"] = (
        out[f"R_sigma_norm_pred{tag}"]
        + out[f"R_W_norm_pred{tag}"]
        - out[f"epsilon_res_8_norm_pred{tag}"]
    )

    out[f"FSI_degradation_true{tag}"] = (
        out[f"R_sigma_norm_true{tag}"]
        + out[f"R_W_norm_true{tag}"]
        - out[f"Delta_epsilon_res_norm_true{tag}"]
    )

    out[f"FSI_degradation_pred{tag}"] = (
        out[f"R_sigma_norm_pred{tag}"]
        + out[f"R_W_norm_pred{tag}"]
        - out[f"Delta_epsilon_res_norm_pred{tag}"]
    )

    out[f"FSI_mean_true{tag}"] = (
        out[f"FSI_final_state_true{tag}"]
        + out[f"FSI_degradation_true{tag}"]
    ) / 2.0

    out[f"FSI_mean_pred{tag}"] = (
        out[f"FSI_final_state_pred{tag}"]
        + out[f"FSI_degradation_pred{tag}"]
    ) / 2.0

    return out


def calc_metric_table(compare_df, true_col, pred_col):
    data = compare_df[[true_col, pred_col]].dropna().copy()

    if len(data) == 0:
        return {
            "descriptor": true_col.replace("_true", ""),
            "n": 0,
            "R2": np.nan,
            "MAE": np.nan,
            "RMSE": np.nan,
        }

    return {
        "descriptor": true_col.replace("_true", ""),
        "n": len(data),
        "R2": r2_score(data[true_col], data[pred_col]),
        "MAE": mean_absolute_error(data[true_col], data[pred_col]),
        "RMSE": rmse(data[true_col], data[pred_col]),
    }


def plot_parity(compare_df, true_col, pred_col, file_name, xlabel, ylabel):
    data = compare_df[[true_col, pred_col]].dropna().copy()

    if len(data) == 0:
        return

    y_true = data[true_col].to_numpy()
    y_pred = data[pred_col].to_numpy()

    r2 = r2_score(y_true, y_pred)
    mae = mean_absolute_error(y_true, y_pred)
    rmse_val = rmse(y_true, y_pred)

    plt.figure(figsize=(5.5, 5.5))
    plt.scatter(
        y_true,
        y_pred,
        s=28,
        alpha=0.75,
        edgecolors="k",
        linewidths=0.3
    )

    vmin = min(y_true.min(), y_pred.min())
    vmax = max(y_true.max(), y_pred.max())

    plt.plot([vmin, vmax], [vmin, vmax], "k--", linewidth=1.2)

    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.title(f"R²={r2:.3f}, MAE={mae:.3f}, RMSE={rmse_val:.3f}")

    plt.tight_layout()
    plt.savefig(FIG_DIR / file_name, dpi=300)
    plt.close()


# =========================================================
# 4. 读取 GroupKFold 预测结果
# =========================================================

print("=" * 80)
print("Reading GroupKFold prediction file:")
print(OOF_PATH)
print("=" * 80)

df = pd.read_excel(OOF_PATH, sheet_name="oof_predictions")

if "__row_order" not in df.columns:
    df["__row_order"] = np.arange(len(df))

required_cols = [
    COL_ID,
    COL_DMIN,
    COL_DMAX,
    COL_GD,
    COL_GB,
    COL_EMAX,
    COL_T,
    COL_CYCLE,
    COL_STATUS,
    COL_STRAIN,
    COL_TRUE,
    COL_PRED,
]

missing = [c for c in required_cols if c not in df.columns]
if missing:
    raise ValueError(f"GroupKFold prediction 文件缺少这些列：{missing}")

for c in [
    COL_DMIN,
    COL_DMAX,
    COL_GD,
    COL_GB,
    COL_EMAX,
    COL_T,
    COL_CYCLE,
    COL_STATUS,
    COL_STRAIN,
    COL_TRUE,
    COL_PRED,
]:
    df[c] = pd.to_numeric(df[c], errors="coerce")

if COL_DAVG in df.columns:
    df[COL_DAVG] = pd.to_numeric(df[COL_DAVG], errors="coerce")

df = df.dropna(subset=required_cols).copy()

print("GroupKFold predictions loaded.")
print("Rows:", len(df))
print("Unique IDs:", df[COL_ID].nunique())


# =========================================================
# 5. 分别计算 true 和 pred 的循环指标
# =========================================================

cycle_true, id_true = build_descriptors(df, COL_TRUE, "true")
cycle_pred, id_pred = build_descriptors(df, COL_PRED, "pred")


# =========================================================
# 6. 合并 true / pred 指标
# =========================================================

meta_cols = [COL_ID, COL_T, COL_EMAX, COL_DMIN, COL_DMAX]

if COL_DAVG in id_true.columns:
    meta_cols.append(COL_DAVG)

meta_cols += [COL_GD, COL_GB]

true_metric_cols = [c for c in id_true.columns if c.endswith("_true")]
pred_metric_cols = [c for c in id_pred.columns if c.endswith("_pred")]

compare = id_true[meta_cols + true_metric_cols].merge(
    id_pred[GROUP_KEYS_CONDITION + pred_metric_cols],
    on=GROUP_KEYS_CONDITION,
    how="left"
)


# =========================================================
# 7. 全数据范围 FSI
# =========================================================

compare = add_fsi_columns(compare, suffix="")


# =========================================================
# 8. descriptor-level 预测精度，全数据范围
# =========================================================

descriptor_pairs_all = [
    ("sigma_max_8_GPa_true", "sigma_max_8_GPa_pred"),
    ("epsilon_res_8_percent_true", "epsilon_res_8_percent_pred"),
    ("DeltaW_8_MJ_m3_true", "DeltaW_8_MJ_m3_pred"),
    ("R_sigma_true", "R_sigma_pred"),
    ("R_W_true", "R_W_pred"),
    ("Delta_epsilon_res_percent_true", "Delta_epsilon_res_percent_pred"),
    ("FSI_final_state_true", "FSI_final_state_pred"),
    ("FSI_degradation_true", "FSI_degradation_pred"),
    ("FSI_mean_true", "FSI_mean_pred"),
]

descriptor_metrics_all = pd.DataFrame(
    [calc_metric_table(compare, t, p) for t, p in descriptor_pairs_all]
)


# =========================================================
# 9. 主工况 400 K, 10% 内部 local FSI
# =========================================================

main = compare[
    np.isclose(compare[COL_T], 400)
    & np.isclose(compare[COL_EMAX], 10)
].copy()

main = add_fsi_columns(main, suffix="local")

descriptor_pairs_main = [
    ("sigma_max_8_GPa_true", "sigma_max_8_GPa_pred"),
    ("epsilon_res_8_percent_true", "epsilon_res_8_percent_pred"),
    ("DeltaW_8_MJ_m3_true", "DeltaW_8_MJ_m3_pred"),
    ("R_sigma_true", "R_sigma_pred"),
    ("R_W_true", "R_W_pred"),
    ("Delta_epsilon_res_percent_true", "Delta_epsilon_res_percent_pred"),
    ("FSI_final_state_true_local", "FSI_final_state_pred_local"),
    ("FSI_degradation_true_local", "FSI_degradation_pred_local"),
    ("FSI_mean_true_local", "FSI_mean_pred_local"),
]

descriptor_metrics_main = pd.DataFrame(
    [calc_metric_table(main, t, p) for t, p in descriptor_pairs_main]
)

main_rank_true = main.sort_values("FSI_mean_true_local", ascending=False)
main_rank_pred = main.sort_values("FSI_mean_pred_local", ascending=False)


# =========================================================
# 10. 保存 parity 图，全数据范围
# =========================================================

plot_parity(
    compare,
    "sigma_max_8_GPa_true",
    "sigma_max_8_GPa_pred",
    "parity_sigma_max_8_all.png",
    r"MD $\sigma_{max,8}$ (GPa)",
    r"GRU GroupKFold $\sigma_{max,8}$ (GPa)"
)

plot_parity(
    compare,
    "epsilon_res_8_percent_true",
    "epsilon_res_8_percent_pred",
    "parity_epsilon_res_8_all.png",
    r"MD $\varepsilon_{res,8}$ (%)",
    r"GRU GroupKFold $\varepsilon_{res,8}$ (%)"
)

plot_parity(
    compare,
    "DeltaW_8_MJ_m3_true",
    "DeltaW_8_MJ_m3_pred",
    "parity_DeltaW_8_all.png",
    r"MD $\Delta W_8$ (MJ/m$^3$)",
    r"GRU GroupKFold $\Delta W_8$ (MJ/m$^3$)"
)

plot_parity(
    compare,
    "R_sigma_true",
    "R_sigma_pred",
    "parity_R_sigma_all.png",
    r"MD $R_{\sigma}$",
    r"GRU GroupKFold $R_{\sigma}$"
)

plot_parity(
    compare,
    "R_W_true",
    "R_W_pred",
    "parity_R_W_all.png",
    r"MD $R_W$",
    r"GRU GroupKFold $R_W$"
)

plot_parity(
    compare,
    "FSI_mean_true",
    "FSI_mean_pred",
    "parity_FSI_mean_all.png",
    r"MD FSI mean",
    r"GRU GroupKFold FSI mean"
)


# =========================================================
# 11. 保存 parity 图，主工况 local FSI
# =========================================================

plot_parity(
    main,
    "FSI_mean_true_local",
    "FSI_mean_pred_local",
    "parity_FSI_mean_main_400K_10pct_local.png",
    r"MD FSI mean, local",
    r"GRU GroupKFold FSI mean, local"
)


# =========================================================
# 12. 保存 Excel
# =========================================================

with pd.ExcelWriter(OUTPUT_EXCEL, engine="openpyxl") as writer:
    cycle_true.to_excel(writer, sheet_name="cycle_level_true", index=False)
    cycle_pred.to_excel(writer, sheet_name="cycle_level_pred", index=False)
    id_true.to_excel(writer, sheet_name="ID_condition_true", index=False)
    id_pred.to_excel(writer, sheet_name="ID_condition_pred", index=False)

    compare.to_excel(writer, sheet_name="true_vs_pred_metrics_all", index=False)
    descriptor_metrics_all.to_excel(writer, sheet_name="descriptor_accuracy_all", index=False)

    main.to_excel(writer, sheet_name="main_400K_10pct", index=False)
    descriptor_metrics_main.to_excel(writer, sheet_name="descriptor_accuracy_main", index=False)
    main_rank_true.to_excel(writer, sheet_name="main_rank_true_FSI_local", index=False)
    main_rank_pred.to_excel(writer, sheet_name="main_rank_pred_FSI_local", index=False)


# =========================================================
# 13. 控制台输出
# =========================================================

print("\nDescriptor-level metrics, all data:")
print(descriptor_metrics_all.to_string(index=False))

print("\nDescriptor-level metrics, main condition 400 K, 10%:")
print(descriptor_metrics_main.to_string(index=False))

print("\nMain condition true Top 5, local FSI:")
print(
    main_rank_true[
        [
            COL_ID,
            COL_GD,
            "FSI_mean_true_local",
            "FSI_mean_pred_local",
            "epsilon_res_8_percent_true",
            "epsilon_res_8_percent_pred",
            "R_W_true",
            "R_W_pred",
        ]
    ].head(5).to_string(index=False)
)

print("\nMain condition pred Top 5, local FSI:")
print(
    main_rank_pred[
        [
            COL_ID,
            COL_GD,
            "FSI_mean_true_local",
            "FSI_mean_pred_local",
            "epsilon_res_8_percent_true",
            "epsilon_res_8_percent_pred",
            "R_W_true",
            "R_W_pred",
        ]
    ].head(5).to_string(index=False)
)

print("\nSaved:")
print(OUTPUT_EXCEL)
print(FIG_DIR)