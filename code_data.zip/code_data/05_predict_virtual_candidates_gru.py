# -*- coding: utf-8 -*-
"""
08_predict_virtual_candidates_gru_sequence.py

Sequence-GRU version of virtual candidate prediction.

This script replaces the old point-wise GRU prediction step with the new
sequence GRU trained by:

    05_train_gru_sequence_final.py

Default behavior:
    - Read all 234 virtual candidates from sheet "virtual_candidates_all".
    - Build a candidate-specific 400 K / 10% path by interpolating the two
      real source paths recorded in the candidate table.
    - Keep the original measured path resolution for GRU inference. Optional
      interpolation belongs after prediction, not inside the GRU sequence.
    - Predict each candidate and each cycle as a complete sequence.
    - Save outputs using the old 09-compatible path:

        E:\\TiNi_4_code\\virtual_predictions\\virtual_gru_predictions.xlsx

Important:
    The old 08 used a point-wise GRU with seq_len=1. This script uses the new
    sequence checkpoint:

        E:\\TiNi_4_code\\gru_sequence_final_v3_packed_bestepoch_h256_lr1e3
"""

from pathlib import Path
from datetime import datetime
import json
import shutil
import warnings

import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from torch.nn.utils.rnn import pad_sequence, pack_padded_sequence, pad_packed_sequence


warnings.filterwarnings("ignore")


# ============================================================
# 1. Paths
# ============================================================

BASE_DIR = Path(r"E:\TiNi_4_code")

DATA_PATH = BASE_DIR / "Dataset.xlsx"
CANDIDATE_PATH = BASE_DIR / "virtual_candidates" / "virtual_design_candidates.xlsx"

SEQUENCE_MODEL_DIR = BASE_DIR / "gru_sequence_final_v3_packed_bestepoch_h256_lr1e3"
CKPT_PATH = SEQUENCE_MODEL_DIR / "checkpoints" / "GRU_sequence_final_full.pth"
SCALER_X_PATH = SEQUENCE_MODEL_DIR / "scalers" / "scaler_x_sequence_final.pkl"
SCALER_Y_PATH = SEQUENCE_MODEL_DIR / "scalers" / "scaler_y_sequence_final.pkl"

# Keep this output folder/name compatible with 09_calc_virtual_candidate_metrics.py.
OUTPUT_DIR = BASE_DIR / "virtual_predictions"
FIG_DIR = OUTPUT_DIR / "figures_sequence_v3_source_paths"

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
FIG_DIR.mkdir(parents=True, exist_ok=True)

OUTPUT_EXCEL = OUTPUT_DIR / "virtual_gru_predictions_234_source_paths.xlsx"
OUTPUT_CSV = OUTPUT_DIR / "virtual_gru_predictions_234_source_paths.csv"
RUN_INFO_JSON = OUTPUT_DIR / "virtual_prediction_run_info_sequence_v3_source_paths.json"


# ============================================================
# 2. Basic settings
# ============================================================

DATA_SHEET = "\u5168\u90e8"  # "全部"

# Complete virtual design space: all 234 candidates.
CANDIDATE_SHEET = "virtual_candidates_all"

MAIN_T = 400
MAIN_EMAX = 10

SEQ_BATCH_SIZE = 64
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

BACKUP_EXISTING_OUTPUTS = True


# ============================================================
# 3. Unloading densification
# ============================================================

# Never densify before a sequence model: it changes sequence length/context and
# creates an input distribution that was not seen during training.
DENSIFY_UNLOADING = False
DENSE_MIN_STRAIN = 0.0
DENSE_MAX_STRAIN = 3.0
DENSE_STEP = 0.02


# ============================================================
# 4. Columns and features
# ============================================================

COL_ID = "ID"
COL_CANDIDATE_ID = "candidate_id"

COL_DMIN = "d_min (nm)"
COL_DMAX = "d_max (nm)"
COL_DAVG = "Davg"
COL_GD = "gd"
COL_GB = "GB_frac0"

COL_EMAX = "Max Strain(%)"
COL_T = "T (K)"

COL_CYCLE = "cycle_n"
COL_STATUS = "Load_Status"
COL_STRAIN = "Current_Strain"

COL_PRED = "Current_Stress_pred"

DEFAULT_FEATURES = [
    COL_DMIN,
    COL_DMAX,
    COL_DAVG,
    COL_GD,
    COL_GB,
    COL_EMAX,
    COL_T,
    COL_CYCLE,
    COL_STATUS,
    COL_STRAIN,
]

GROUP_KEYS_SEQUENCE = [COL_CANDIDATE_ID, COL_T, COL_EMAX, COL_CYCLE]


# ============================================================
# 5. Sequence GRU model, same architecture as corrected sequence 05 v3
# ============================================================

class GRUSeqRegressor(nn.Module):
    def __init__(
        self,
        input_dim,
        hidden_size=256,
        num_layers=2,
        dropout=0.0,
        bidirectional=True,
    ):
        super().__init__()
        self.bidirectional = bidirectional

        self.input_proj = nn.Sequential(
            nn.Linear(input_dim, hidden_size),
            nn.ReLU(),
            nn.LayerNorm(hidden_size),
        )

        self.gru = nn.GRU(
            input_size=hidden_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0.0,
            bidirectional=bidirectional,
        )

        self.local_branch = nn.Sequential(
            nn.Linear(input_dim, hidden_size),
            nn.ReLU(),
            nn.LayerNorm(hidden_size),
            nn.Linear(hidden_size, hidden_size),
            nn.ReLU(),
        )

        gru_dim = hidden_size * (2 if bidirectional else 1)

        self.head = nn.Sequential(
            nn.Linear(gru_dim + hidden_size, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, hidden_size // 2),
            nn.ReLU(),
            nn.Linear(hidden_size // 2, 1),
        )

    def forward(self, x, lengths=None):
        z = self.input_proj(x)
        if lengths is None:
            seq_context, _ = self.gru(z)
        else:
            packed = pack_padded_sequence(
                z,
                lengths.detach().cpu(),
                batch_first=True,
                enforce_sorted=False,
            )
            packed_context, _ = self.gru(packed)
            seq_context, _ = pad_packed_sequence(
                packed_context,
                batch_first=True,
                total_length=x.shape[1],
            )
        local_context = self.local_branch(x)
        y = self.head(torch.cat([seq_context, local_context], dim=-1)).squeeze(-1)
        return y


# ============================================================
# 6. Utilities
# ============================================================

def read_excel_safely(path, preferred_sheet=None):
    xls = pd.ExcelFile(path)
    if preferred_sheet is not None and preferred_sheet in xls.sheet_names:
        return pd.read_excel(path, sheet_name=preferred_sheet), preferred_sheet
    first_sheet = xls.sheet_names[0]
    print(f"Preferred sheet {preferred_sheet!r} not found; using {first_sheet!r}.")
    return pd.read_excel(path, sheet_name=first_sheet), first_sheet


def backup_if_exists(path):
    if not BACKUP_EXISTING_OUTPUTS or not path.exists():
        return None

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = path.with_name(f"{path.stem}.backup_{timestamp}{path.suffix}")
    shutil.copy2(path, backup_path)
    return backup_path


def load_sequence_model():
    if not CKPT_PATH.exists():
        raise FileNotFoundError(f"Cannot find sequence checkpoint: {CKPT_PATH}")

    checkpoint = torch.load(CKPT_PATH, map_location=DEVICE)
    if not isinstance(checkpoint, dict) or "model_state_dict" not in checkpoint:
        raise ValueError("Sequence checkpoint must contain 'model_state_dict'.")

    features = checkpoint.get("features", DEFAULT_FEATURES)
    input_dim = int(checkpoint.get("input_dim", len(features)))
    hidden_size = int(checkpoint.get("hidden_size", 256))
    num_layers = int(checkpoint.get("num_layers", 2))
    dropout = float(checkpoint.get("dropout", 0.0))
    bidirectional = bool(checkpoint.get("bidirectional", True))

    model = GRUSeqRegressor(
        input_dim=input_dim,
        hidden_size=hidden_size,
        num_layers=num_layers,
        dropout=dropout,
        bidirectional=bidirectional,
    ).to(DEVICE)

    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()

    print("\nLoaded sequence GRU model:")
    print("checkpoint  =", CKPT_PATH)
    print("input_dim   =", input_dim)
    print("hidden_size =", hidden_size)
    print("num_layers  =", num_layers)
    print("dropout     =", dropout)
    print("bidirectional =", bidirectional)
    print("features:")
    for f in features:
        print("  -", f)

    return model, features, checkpoint


def select_standard_template(real_df):
    needed = [COL_ID, COL_T, COL_EMAX, COL_CYCLE, COL_STATUS, COL_STRAIN]
    missing = [c for c in needed if c not in real_df.columns]
    if missing:
        raise ValueError(f"Dataset is missing template columns: {missing}")

    df = real_df.copy()
    if "__row_order" not in df.columns:
        df["__row_order"] = np.arange(len(df))

    for c in [COL_T, COL_EMAX, COL_CYCLE, COL_STATUS, COL_STRAIN]:
        df[c] = pd.to_numeric(df[c], errors="coerce")

    df = df.dropna(subset=needed).copy()

    main_df = df[(df[COL_T] == MAIN_T) & (df[COL_EMAX] == MAIN_EMAX)].copy()
    if len(main_df) == 0:
        raise ValueError(f"No template data found for T={MAIN_T} K, Max Strain={MAIN_EMAX}%.")

    id_counts = main_df.groupby(COL_ID).size().sort_values(ascending=False)
    template_id = id_counts.index[0]

    template_raw = main_df[main_df[COL_ID] == template_id].copy()
    template_raw = template_raw.sort_values("__row_order").reset_index(drop=True)

    template_df = template_raw[[COL_T, COL_EMAX, COL_CYCLE, COL_STATUS, COL_STRAIN]].copy()
    template_df["template_row_order"] = np.arange(len(template_df))
    template_df["template_source_ID"] = template_id

    return template_df, template_id


def densify_unloading_template_for_residual(
    template_df,
    dense_min_strain=0.0,
    dense_max_strain=3.0,
    dense_step=0.02,
):
    template_df = template_df.copy()
    if "template_row_order" not in template_df.columns:
        template_df["template_row_order"] = np.arange(len(template_df))

    dense_all = []

    for cycle, cycle_df in template_df.groupby(COL_CYCLE, sort=True):
        cycle_df = cycle_df.sort_values("template_row_order").copy()

        loading_df = cycle_df[cycle_df[COL_STATUS] == 1].copy()
        unload_df = cycle_df[cycle_df[COL_STATUS] == -1].copy()

        if len(loading_df) > 0:
            dense_all.append(loading_df)

        if len(unload_df) == 0:
            continue

        original_strains = unload_df[COL_STRAIN].to_numpy(dtype=float)
        s_min = max(dense_min_strain, np.nanmin(original_strains))
        s_max = min(dense_max_strain, np.nanmax(original_strains))

        if s_max <= s_min:
            dense_all.append(unload_df)
            continue

        dense_strains = np.arange(s_min, s_max + dense_step * 0.5, dense_step)
        merged_strains = np.unique(np.concatenate([original_strains, dense_strains]))

        if original_strains[0] > original_strains[-1]:
            merged_strains = np.sort(merged_strains)[::-1]
        else:
            merged_strains = np.sort(merged_strains)

        new_rows = []
        for s in merged_strains:
            nearest_idx = np.argmin(np.abs(original_strains - s))
            base_row = unload_df.iloc[nearest_idx].copy()
            base_row[COL_STRAIN] = float(s)
            base_row[COL_STATUS] = -1
            base_row[COL_CYCLE] = cycle
            new_rows.append(base_row)

        dense_all.append(pd.DataFrame(new_rows))

    out = pd.concat(dense_all, axis=0, ignore_index=True)
    out["template_row_order"] = np.arange(len(out))
    return out


def prepare_candidates(cand_df):
    df = cand_df.copy()

    if COL_CANDIDATE_ID not in df.columns:
        df[COL_CANDIDATE_ID] = [f"virtual_{i + 1:05d}" for i in range(len(df))]

    if COL_DAVG not in df.columns and COL_DMIN in df.columns and COL_DMAX in df.columns:
        df[COL_DAVG] = (
            pd.to_numeric(df[COL_DMIN], errors="coerce")
            + pd.to_numeric(df[COL_DMAX], errors="coerce")
        ) / 2.0

    if COL_GD not in df.columns and COL_DMIN in df.columns and COL_DMAX in df.columns:
        dmin = pd.to_numeric(df[COL_DMIN], errors="coerce")
        dmax = pd.to_numeric(df[COL_DMAX], errors="coerce")
        df[COL_GD] = dmax / dmin - 1.0

    required = [COL_CANDIDATE_ID, COL_DMIN, COL_DMAX, COL_DAVG, COL_GD, COL_GB]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Candidate table is missing columns: {missing}")

    for c in [COL_DMIN, COL_DMAX, COL_DAVG, COL_GD, COL_GB]:
        df[c] = pd.to_numeric(df[c], errors="coerce")

    df = df.dropna(subset=required).copy()
    df = df.reset_index(drop=True)
    return df


def build_source_path_library(real_df):
    """Collect all observed 400 K / 10% cycle paths keyed by real ID."""
    df = real_df.copy()
    if "__row_order" not in df.columns:
        df["__row_order"] = np.arange(len(df))

    for c in [COL_T, COL_EMAX, COL_CYCLE, COL_STATUS, COL_STRAIN]:
        df[c] = pd.to_numeric(df[c], errors="coerce")

    df = df[
        (df[COL_T] == MAIN_T)
        & (df[COL_EMAX] == MAIN_EMAX)
    ].dropna(subset=[COL_ID, COL_CYCLE, COL_STATUS, COL_STRAIN]).copy()

    library = {}
    for source_id, group in df.groupby(COL_ID, sort=False):
        library[str(source_id)] = group.sort_values("__row_order").copy()
    return library


def resample_1d(values, n_points):
    values = np.asarray(values, dtype=float)
    if len(values) == n_points:
        return values.copy()
    old_t = np.linspace(0.0, 1.0, len(values))
    new_t = np.linspace(0.0, 1.0, n_points)
    return np.interp(new_t, old_t, values)


def monotonic_branch_strain(values, status):
    """Return a physically ordered strain branch without changing endpoints."""
    values = np.asarray(values, dtype=float)
    values = np.sort(values)
    if status == -1:
        values = values[::-1]
    return values


def interpolate_candidate_template(cand, source_paths, fallback_template):
    """Interpolate loading/unloading strain paths from candidate source IDs."""
    source_a = str(cand.get("source_ID_A", ""))
    source_b = str(cand.get("source_ID_B", ""))
    alpha = float(cand.get("alpha_from_A_to_B", 0.5))
    alpha = float(np.clip(alpha, 0.0, 1.0))

    if source_a not in source_paths or source_b not in source_paths:
        out = fallback_template.copy()
        out["template_mode"] = "fallback_single_template"
        return out

    path_a = source_paths[source_a]
    path_b = source_paths[source_b]
    frames = []

    common_cycles = sorted(
        set(path_a[COL_CYCLE].unique()).intersection(path_b[COL_CYCLE].unique())
    )
    for cycle in common_cycles:
        for status in [1, -1]:
            a = path_a[
                (path_a[COL_CYCLE] == cycle) & (path_a[COL_STATUS] == status)
            ].sort_values("__row_order")
            b = path_b[
                (path_b[COL_CYCLE] == cycle) & (path_b[COL_STATUS] == status)
            ].sort_values("__row_order")

            if len(a) == 0 or len(b) == 0:
                continue

            # Interpolate the number of points as well as the strain path so
            # sequence lengths stay inside the observed source distribution.
            n_points = max(2, int(round((1.0 - alpha) * len(a) + alpha * len(b))))
            strain_a_raw = monotonic_branch_strain(
                a[COL_STRAIN].to_numpy(dtype=float), status
            )
            strain_b_raw = monotonic_branch_strain(
                b[COL_STRAIN].to_numpy(dtype=float), status
            )
            strain_a = resample_1d(strain_a_raw, n_points)
            strain_b = resample_1d(strain_b_raw, n_points)
            strain = (1.0 - alpha) * strain_a + alpha * strain_b

            frames.append(pd.DataFrame({
                COL_T: MAIN_T,
                COL_EMAX: MAIN_EMAX,
                COL_CYCLE: cycle,
                COL_STATUS: status,
                COL_STRAIN: strain,
            }))

    if not frames:
        out = fallback_template.copy()
        out["template_mode"] = "fallback_single_template"
        return out

    out = pd.concat(frames, axis=0, ignore_index=True)
    out["template_row_order"] = np.arange(len(out))
    out["template_source_ID"] = f"{source_a}->{source_b}"
    out["template_mode"] = "source_path_interpolation"
    return out


def build_virtual_prediction_table(candidates, source_paths, fallback_template):
    all_rows = []

    candidate_meta_cols = [
        c for c in candidates.columns
        if c not in [COL_T, COL_EMAX, COL_CYCLE, COL_STATUS, COL_STRAIN]
    ]

    for _, cand in candidates.iterrows():
        temp = interpolate_candidate_template(cand, source_paths, fallback_template)

        for c in candidate_meta_cols:
            temp[c] = cand[c]

        temp[COL_CANDIDATE_ID] = cand[COL_CANDIDATE_ID]
        temp[COL_ID] = cand[COL_CANDIDATE_ID]
        temp[COL_T] = MAIN_T
        temp[COL_EMAX] = MAIN_EMAX

        all_rows.append(temp)

    virtual_df = pd.concat(all_rows, axis=0, ignore_index=True)
    virtual_df["virtual_row_order"] = np.arange(len(virtual_df))
    return virtual_df


def validate_virtual_paths(virtual_df):
    """Fail fast if any candidate cycle is incomplete or non-monotonic."""
    errors = []
    for key, group in virtual_df.groupby(GROUP_KEYS_SEQUENCE, sort=False):
        group = group.sort_values("template_row_order")
        statuses = set(group[COL_STATUS].astype(int).unique())
        if statuses != {1, -1}:
            errors.append(f"{key}: statuses={sorted(statuses)}")
            continue

        loading = group[group[COL_STATUS] == 1][COL_STRAIN].to_numpy(dtype=float)
        unloading = group[group[COL_STATUS] == -1][COL_STRAIN].to_numpy(dtype=float)
        if np.any(np.diff(loading) < -1e-10):
            errors.append(f"{key}: loading strain is not monotonic increasing")
        if np.any(np.diff(unloading) > 1e-10):
            errors.append(f"{key}: unloading strain is not monotonic decreasing")

    if errors:
        preview = "\n".join(errors[:10])
        raise ValueError(f"Virtual path validation failed ({len(errors)} groups):\n{preview}")

    print("Virtual path validation: all sequences complete and monotonic.")


class VirtualCurveDataset(Dataset):
    def __init__(self, items):
        self.items = items

    def __len__(self):
        return len(self.items)

    def __getitem__(self, idx):
        item = self.items[idx]
        return {
            "X": torch.tensor(item["X"], dtype=torch.float32),
            "row_index": torch.tensor(item["row_index"], dtype=torch.long),
            "meta": item["meta"],
        }


def collate_virtual_batch(batch):
    X = pad_sequence([b["X"] for b in batch], batch_first=True, padding_value=0.0)
    row_index = pad_sequence([b["row_index"] for b in batch], batch_first=True, padding_value=-1)
    lengths = torch.tensor([len(b["X"]) for b in batch], dtype=torch.long)
    meta = [b["meta"] for b in batch]
    return {"X": X, "row_index": row_index, "lengths": lengths, "meta": meta}


def make_virtual_sequence_items(virtual_df, features, scaler_x):
    items = []

    for key, group in virtual_df.groupby(GROUP_KEYS_SEQUENCE, sort=False):
        group = group.sort_values("template_row_order").copy()
        idx = group.index.to_numpy(dtype=np.int64)

        X = group[features].to_numpy(dtype=np.float32)
        X_scaled = scaler_x.transform(X).astype(np.float32)

        meta = {
            COL_CANDIDATE_ID: key[0],
            COL_T: key[1],
            COL_EMAX: key[2],
            COL_CYCLE: key[3],
        }

        items.append({
            "X": X_scaled,
            "row_index": idx,
            "meta": meta,
        })

    return items


def predict_virtual_sequences(model, items, scaler_y, n_rows):
    dataset = VirtualCurveDataset(items)
    loader = DataLoader(
        dataset,
        batch_size=SEQ_BATCH_SIZE,
        shuffle=False,
        num_workers=0,
        pin_memory=False,
        collate_fn=collate_virtual_batch,
    )

    pred_all = np.full(n_rows, np.nan, dtype=np.float32)

    model.eval()
    with torch.no_grad():
        for batch in loader:
            X = batch["X"].to(DEVICE)
            pred_scaled = model(X, batch["lengths"]).cpu().numpy()
            lengths = batch["lengths"].numpy()
            row_index = batch["row_index"].numpy()

            pred_phys = scaler_y.inverse_transform(pred_scaled.reshape(-1, 1)).reshape(pred_scaled.shape)

            for i, L in enumerate(lengths):
                idx = row_index[i, :L]
                pred_all[idx] = pred_phys[i, :L]

    return pred_all


def quick_plot_check(pred_df, max_candidates=3):
    ids = pred_df[COL_CANDIDATE_ID].drop_duplicates().head(max_candidates).tolist()

    for cid in ids:
        sub = pred_df[
            (pred_df[COL_CANDIDATE_ID] == cid)
            & (pred_df[COL_CYCLE].isin([1, 8]))
        ].copy()

        if len(sub) == 0:
            continue

        plt.figure(figsize=(6.2, 4.8))

        for cyc in [1, 8]:
            s = sub[sub[COL_CYCLE] == cyc].sort_values("template_row_order")
            if len(s) == 0:
                continue

            plt.plot(
                s[COL_STRAIN],
                s[COL_PRED],
                linewidth=1.2,
                label=f"cycle {cyc}",
            )

        plt.xlabel("Current strain (%)")
        plt.ylabel("Predicted stress (GPa)")
        plt.title(f"Sequence GRU virtual check: {cid}")
        plt.legend(frameon=False)
        plt.tight_layout()

        safe_cid = str(cid).replace("/", "_").replace("\\", "_").replace(":", "_")
        plt.savefig(FIG_DIR / f"quick_check_sequence_{safe_cid}.png", dpi=300)
        plt.close()


# ============================================================
# 7. Main
# ============================================================

print("=" * 80)
print("08_predict_virtual_candidates_gru_sequence.py")
print("=" * 80)
print("Device:", DEVICE)

for p in [DATA_PATH, CANDIDATE_PATH, CKPT_PATH, SCALER_X_PATH, SCALER_Y_PATH]:
    if not p.exists():
        raise FileNotFoundError(f"Required file not found: {p}")


print("\nReading Dataset.xlsx...")
real_df, used_data_sheet = read_excel_safely(DATA_PATH, DATA_SHEET)
print("Used data sheet:", used_data_sheet)
print("Dataset rows:", len(real_df))


print("\nSelecting standard path template...")
template_df, template_source_id = select_standard_template(real_df)
print("Template source ID:", template_source_id)
print("Template rows before densifying:", len(template_df))
print("Template cycles:", sorted(template_df[COL_CYCLE].unique().tolist()))

if DENSIFY_UNLOADING:
    template_df = densify_unloading_template_for_residual(
        template_df,
        dense_min_strain=DENSE_MIN_STRAIN,
        dense_max_strain=DENSE_MAX_STRAIN,
        dense_step=DENSE_STEP,
    )

print("Template rows after densifying:", len(template_df))
print("Unloading rows after densifying:", len(template_df[template_df[COL_STATUS] == -1]))


print("\nReading virtual candidates...")
candidate_df, used_candidate_sheet = read_excel_safely(CANDIDATE_PATH, CANDIDATE_SHEET)
print("Used candidate sheet:", used_candidate_sheet)
print("Candidate rows before cleaning:", len(candidate_df))

candidates = prepare_candidates(candidate_df)
print("Candidate rows after cleaning:", len(candidates))
print("gd range:", candidates[COL_GD].min(), "to", candidates[COL_GD].max())
print("Davg range:", candidates[COL_DAVG].min(), "to", candidates[COL_DAVG].max())


print("\nBuilding virtual prediction table...")
source_paths = build_source_path_library(real_df)
print("Available real source paths:", len(source_paths))
virtual_df = build_virtual_prediction_table(candidates, source_paths, template_df)
print("Virtual prediction rows:", len(virtual_df))
print("Virtual candidates:", virtual_df[COL_CANDIDATE_ID].nunique())
print("Template modes:", virtual_df["template_mode"].value_counts().to_dict())
validate_virtual_paths(virtual_df)


print("\nLoading sequence model and scalers...")
model, features, checkpoint = load_sequence_model()
scaler_x = joblib.load(SCALER_X_PATH)
scaler_y = joblib.load(SCALER_Y_PATH)

missing_features = [c for c in features if c not in virtual_df.columns]
if missing_features:
    raise ValueError(f"virtual_df is missing checkpoint features: {missing_features}")

for c in features:
    virtual_df[c] = pd.to_numeric(virtual_df[c], errors="coerce")

before_drop = len(virtual_df)
virtual_df = virtual_df.dropna(subset=features).copy()
virtual_df = virtual_df.reset_index(drop=True)
after_drop = len(virtual_df)

if after_drop < before_drop:
    print(f"Dropped {before_drop - after_drop} rows with NaN model features.")

# Report extrapolation before inference. Large standardized magnitudes are a
# warning that a virtual design lies outside the model's training support.
scaled_diagnostic = scaler_x.transform(virtual_df[features].to_numpy(dtype=np.float32))
max_abs_z = np.nanmax(np.abs(scaled_diagnostic), axis=0)
print("\nMaximum absolute standardized input by feature:")
for feature, value in zip(features, max_abs_z):
    flag = "  <-- extrapolation warning" if value > 3.0 else ""
    print(f"  {feature}: {value:.3f}{flag}")


print("\nPredicting virtual candidates with sequence GRU...")
items = make_virtual_sequence_items(virtual_df, features, scaler_x)
pred = predict_virtual_sequences(
    model=model,
    items=items,
    scaler_y=scaler_y,
    n_rows=len(virtual_df),
)

virtual_df[COL_PRED] = pred

if virtual_df[COL_PRED].isna().any():
    n_nan = int(virtual_df[COL_PRED].isna().sum())
    raise RuntimeError(f"Prediction produced {n_nan} NaN rows.")

print("Prediction finished.")
print("Predicted stress range:", np.nanmin(pred), "to", np.nanmax(pred))


front_cols = [
    COL_CANDIDATE_ID,
    COL_ID,
    "candidate_type",
    "source_ID_A",
    "source_ID_B",
    "alpha_from_A_to_B",
    COL_DMIN,
    COL_DMAX,
    COL_DAVG,
    COL_GD,
    COL_GB,
    "nearest_real_ID",
    "nearest_real_distance_scaled",
    "in_main_gd_range",
    "template_source_ID",
    COL_T,
    COL_EMAX,
    COL_CYCLE,
    COL_STATUS,
    COL_STRAIN,
    "template_row_order",
    "virtual_row_order",
    COL_PRED,
]

front_cols = [c for c in front_cols if c in virtual_df.columns]
other_cols = [c for c in virtual_df.columns if c not in front_cols]
virtual_df = virtual_df[front_cols + other_cols]


print("\nBacking up old prediction outputs if needed...")
backup_excel = backup_if_exists(OUTPUT_EXCEL)
backup_csv = backup_if_exists(OUTPUT_CSV)
if backup_excel is not None:
    print("Excel backup:", backup_excel)
if backup_csv is not None:
    print("CSV backup:", backup_csv)


print("\nSaving virtual prediction results...")
virtual_df.to_csv(OUTPUT_CSV, index=False)

with pd.ExcelWriter(OUTPUT_EXCEL, engine="openpyxl") as writer:
    virtual_df.to_excel(writer, sheet_name="virtual_predictions", index=False)
    candidates.to_excel(writer, sheet_name="virtual_candidates_used", index=False)
    template_df.to_excel(writer, sheet_name="densified_template", index=False)


run_info = {
    "script": "08_predict_virtual_candidates_gru_sequence.py",
    "model_type": "sequence_gru_v3_packed_bestepoch",
    "data_path": str(DATA_PATH),
    "data_sheet_used": used_data_sheet,
    "candidate_path": str(CANDIDATE_PATH),
    "candidate_sheet_used": used_candidate_sheet,
    "sequence_model_dir": str(SEQUENCE_MODEL_DIR),
    "checkpoint_path": str(CKPT_PATH),
    "scaler_x_path": str(SCALER_X_PATH),
    "scaler_y_path": str(SCALER_Y_PATH),
    "output_excel": str(OUTPUT_EXCEL),
    "output_csv": str(OUTPUT_CSV),
    "backup_excel": str(backup_excel) if backup_excel is not None else None,
    "backup_csv": str(backup_csv) if backup_csv is not None else None,
    "main_T": MAIN_T,
    "main_Max_Strain_percent": MAIN_EMAX,
    "template_source_ID": str(template_source_id),
    "template_mode": "candidate_source_path_interpolation",
    "n_source_paths": int(len(source_paths)),
    "dense_unloading": DENSIFY_UNLOADING,
    "dense_min_strain_percent": DENSE_MIN_STRAIN,
    "dense_max_strain_percent": DENSE_MAX_STRAIN,
    "dense_step_percent": DENSE_STEP,
    "template_rows_after_densifying": int(len(template_df)),
    "unloading_rows_after_densifying": int(len(template_df[template_df[COL_STATUS] == -1])),
    "n_virtual_candidates": int(virtual_df[COL_CANDIDATE_ID].nunique()),
    "n_virtual_prediction_rows": int(len(virtual_df)),
    "n_sequence_items": int(len(items)),
    "features": features,
    "device": str(DEVICE),
    "checkpoint_epoch": checkpoint.get("epoch", None),
    "checkpoint_model_type": checkpoint.get("model_type", None),
}

with open(RUN_INFO_JSON, "w", encoding="utf-8") as f:
    json.dump(run_info, f, indent=4, ensure_ascii=False)


print("\nSaving quick check figures...")
quick_plot_check(virtual_df, max_candidates=3)


print("\n" + "=" * 80)
print("08 sequence prediction finished.")
print("=" * 80)
print("\nSaved:")
print(OUTPUT_CSV)
print(OUTPUT_EXCEL)
print(RUN_INFO_JSON)

print("\nNext:")
print("Run 09_calc_virtual_candidate_metrics.py after this, but its real-reference")
print("metrics path must point to the matching sequence-v3 descriptor workbook.")
print(r"Sequence reference workbook:")
print(SEQUENCE_MODEL_DIR / "sequence_cyclic_descriptors.xlsx")
print("\nAll done.")
