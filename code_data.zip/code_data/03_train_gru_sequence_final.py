# -*- coding: utf-8 -*-
"""
05_train_gru_sequence_final.py

True sequence-to-sequence GRU for TiNi stress-strain curves.

Why this script exists
----------------------
The old 05 script used a GRU with seq_len = 1, so each stress point was
predicted independently. This script groups each complete cycle curve as one
sequence:

    ID + T (K) + Max Strain(%) + cycle_n

The model predicts the whole stress sequence. The training loss includes:
    1. point-wise weighted stress MSE
    2. peak-stress auxiliary loss
    3. dissipated-energy auxiliary loss

Outputs are written to a new folder so the old point-wise GRU results are not
overwritten:

    E:\\TiNi_4_code\\gru_sequence_final_v3_packed_bestepoch_h256_lr1e3

After running this script, inspect:
    sequence_cyclic_descriptors.xlsx

Important
---------
This sequence checkpoint is not compatible with the old
08_predict_virtual_candidates_gru.py. A sequence-compatible 08 script is needed
before using the sequence model for virtual candidates.
"""

from pathlib import Path
import random
import warnings

import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from torch.nn.utils.rnn import pad_sequence, pack_padded_sequence, pad_packed_sequence

from sklearn.model_selection import GroupShuffleSplit
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error


warnings.filterwarnings("ignore")


# ============================================================
# 1. Paths
# ============================================================

BASE_DIR = Path(r"E:\TiNi_4_code")
DATA_PATH = BASE_DIR / "Dataset.xlsx"
PREFERRED_SHEET_NAME = "\u5168\u90e8"  # "全部"

# Write corrected packed-sequence/best-epoch results to a new directory so the
# previous v2 experiment remains available for comparison.
OUTPUT_DIR = BASE_DIR / "gru_sequence_final_v3_packed_bestepoch_h256_lr1e3"
CKPT_DIR = OUTPUT_DIR / "checkpoints"
SCALER_DIR = OUTPUT_DIR / "scalers"
HISTORY_DIR = OUTPUT_DIR / "histories"
PRED_DIR = OUTPUT_DIR / "predictions"
FIG_DIR = OUTPUT_DIR / "figures"

for d in [OUTPUT_DIR, CKPT_DIR, SCALER_DIR, HISTORY_DIR, PRED_DIR, FIG_DIR]:
    d.mkdir(parents=True, exist_ok=True)


# ============================================================
# 2. Reproducibility and device
# ============================================================

SEED = 42


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


set_seed(SEED)
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# ============================================================
# 3. Training parameters
# ============================================================

SEQ_BATCH_SIZE = 64
MAX_EPOCHS_FOR_VAL_SEARCH = 300
PATIENCE = 40
# None means: use the best epoch found by the grouped validation search.
# Do not hard-code hundreds of full-data epochs after validation has already
# shown that the model starts to overfit much earlier.
FINAL_EPOCHS = None

LEARNING_RATE = 1e-3
HIDDEN_SIZE = 256
NUM_LAYERS = 2
DROPOUT = 0.0
BIDIRECTIONAL = True
GRAD_CLIP_NORM = 5.0

# Auxiliary loss weights. Point stress fit must stay dominant; peak and energy
# terms only guide descriptors and should not pull the whole curve downward.
POINT_LOSS_WEIGHT = 1.0
PEAK_LOSS_WEIGHT = 0.15
ENERGY_LOSS_WEIGHT = 0.01


# ============================================================
# 4. Columns and features
# ============================================================

COL_ID = "ID"

COL_DMIN = "d_min (nm)"
COL_DMAX = "d_max (nm)"
COL_DAVG = "Davg"
COL_GD = "gd"
COL_GB = "GB_frac0"

COL_EMAX = "Max Strain(%)"
COL_T = "T (K)"

COL_CYCLE = "cycle_n"
COL_STATUS = "Load_Status"
COL_STRAIN = "Current_Strain"

COL_TARGET = "Current_Stress"

FEATURES = [
    COL_DMIN,
    COL_DMAX,
    COL_DAVG,
    COL_GD,
    COL_GB,
    COL_EMAX,
    COL_T,
    COL_CYCLE,
    COL_STATUS,
    COL_STRAIN,
]

GROUP_KEYS_CYCLE = [COL_ID, COL_T, COL_EMAX, COL_CYCLE]
GROUP_KEYS_CONDITION = [COL_ID, COL_T, COL_EMAX]
REQUIRED_COLS = [COL_ID] + FEATURES + [COL_TARGET]


# ============================================================
# 5. Utility functions
# ============================================================

def rmse_score(y_true, y_pred):
    return np.sqrt(mean_squared_error(y_true, y_pred))


def integrate_trapz_np(y, x):
    if hasattr(np, "trapezoid"):
        return np.trapezoid(y, x)
    return np.trapz(y, x)


def integrate_trapz_torch(y, x):
    if y.numel() < 2:
        return y.new_tensor(0.0)
    if hasattr(torch, "trapezoid"):
        return torch.trapezoid(y, x)
    return torch.trapz(y, x)


def minmax_norm_by_ref(s, ref):
    s = s.astype(float)
    ref = ref.astype(float)
    ref_min = ref.min(skipna=True)
    ref_max = ref.max(skipna=True)
    if pd.isna(ref_min) or pd.isna(ref_max):
        return pd.Series(np.nan, index=s.index)
    if ref_max == ref_min:
        return pd.Series(0.5, index=s.index)
    return (s - ref_min) / (ref_max - ref_min)


def build_point_weights(dataframe):
    """
    Point-wise weights:
      - high-stress points get more weight;
      - main condition 400 K / 10% gets extra weight.
    """
    w = np.ones((len(dataframe),), dtype=np.float32)

    stress = dataframe[COL_TARGET].to_numpy(dtype=np.float32)
    s_min = np.nanmin(stress)
    s_max = np.nanmax(stress)
    stress_score = (stress - s_min) / (s_max - s_min + 1e-8)
    w *= 1.0 + 2.0 * stress_score ** 2

    main_mask = (
        (dataframe[COL_T] == 400)
        & (dataframe[COL_EMAX] == 10)
    ).to_numpy()
    w[main_mask] *= 1.5

    return w.astype(np.float32)


class CurveSequenceDataset(Dataset):
    def __init__(self, items):
        self.items = items

    def __len__(self):
        return len(self.items)

    def __getitem__(self, idx):
        item = self.items[idx]
        return {
            "X": torch.tensor(item["X"], dtype=torch.float32),
            "y_scaled": torch.tensor(item["y_scaled"], dtype=torch.float32),
            "y_phys": torch.tensor(item["y_phys"], dtype=torch.float32),
            "strain_frac": torch.tensor(item["strain_frac"], dtype=torch.float32),
            "weights": torch.tensor(item["weights"], dtype=torch.float32),
            "row_index": torch.tensor(item["row_index"], dtype=torch.long),
            "meta": item["meta"],
        }


def collate_curve_batch(batch):
    X = pad_sequence([b["X"] for b in batch], batch_first=True, padding_value=0.0)
    y_scaled = pad_sequence([b["y_scaled"] for b in batch], batch_first=True, padding_value=0.0)
    y_phys = pad_sequence([b["y_phys"] for b in batch], batch_first=True, padding_value=0.0)
    strain_frac = pad_sequence([b["strain_frac"] for b in batch], batch_first=True, padding_value=0.0)
    weights = pad_sequence([b["weights"] for b in batch], batch_first=True, padding_value=0.0)
    row_index = pad_sequence([b["row_index"] for b in batch], batch_first=True, padding_value=-1)

    lengths = torch.tensor([len(b["X"]) for b in batch], dtype=torch.long)
    max_len = X.shape[1]
    mask = torch.arange(max_len).unsqueeze(0) < lengths.unsqueeze(1)
    meta = [b["meta"] for b in batch]

    return {
        "X": X,
        "y_scaled": y_scaled,
        "y_phys": y_phys,
        "strain_frac": strain_frac,
        "weights": weights,
        "row_index": row_index,
        "lengths": lengths,
        "mask": mask,
        "meta": meta,
    }


def make_sequence_items(df, scaler_x, scaler_y):
    """
    Convert a point-level dataframe into a list of complete cycle sequences.
    """
    items = []
    # Keep weights aligned to the dataframe's original index. Train/validation
    # subsets preserve original row labels, so positional indexing is unsafe.
    weights_by_index = pd.Series(build_point_weights(df), index=df.index)

    for key, group in df.groupby(GROUP_KEYS_CYCLE, sort=False):
        group = group.sort_values("__row_order").copy()
        idx = group.index.to_numpy(dtype=np.int64)

        X = group[FEATURES].to_numpy(dtype=np.float32)
        y = group[[COL_TARGET]].to_numpy(dtype=np.float32)

        X_scaled = scaler_x.transform(X).astype(np.float32)
        y_scaled = scaler_y.transform(y).astype(np.float32).reshape(-1)

        strain_frac = (group[COL_STRAIN].to_numpy(dtype=np.float32) / 100.0).astype(np.float32)

        meta = {
            COL_ID: key[0],
            COL_T: key[1],
            COL_EMAX: key[2],
            COL_CYCLE: key[3],
        }

        items.append({
            "X": X_scaled,
            "y_scaled": y_scaled,
            "y_phys": y.reshape(-1).astype(np.float32),
            "strain_frac": strain_frac,
            "weights": weights_by_index.loc[group.index].to_numpy(dtype=np.float32),
            "row_index": idx,
            "meta": meta,
        })

    return items


def make_loader(items, batch_size, shuffle):
    dataset = CurveSequenceDataset(items)
    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=0,
        pin_memory=False,
        collate_fn=collate_curve_batch,
    )


class GRUSeqRegressor(nn.Module):
    """
    Sequence-to-sequence GRU with a local point-wise shortcut.

    The local branch is important for this dataset because the absolute stress
    scale is strongly controlled by local descriptors and current strain. The
    GRU branch learns cycle context, while the local branch protects peak
    stress and dissipated energy from systematic underestimation.

    Input:
        x: (batch, seq_len, input_dim)
    Output:
        y: (batch, seq_len)
    """
    def __init__(
        self,
        input_dim,
        hidden_size=256,
        num_layers=2,
        dropout=0.0,
        bidirectional=True,
    ):
        super().__init__()
        self.bidirectional = bidirectional
        self.input_proj = nn.Sequential(
            nn.Linear(input_dim, hidden_size),
            nn.ReLU(),
            nn.LayerNorm(hidden_size),
        )
        self.gru = nn.GRU(
            input_size=hidden_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0.0,
            bidirectional=bidirectional,
        )
        self.local_branch = nn.Sequential(
            nn.Linear(input_dim, hidden_size),
            nn.ReLU(),
            nn.LayerNorm(hidden_size),
            nn.Linear(hidden_size, hidden_size),
            nn.ReLU(),
        )
        gru_dim = hidden_size * (2 if bidirectional else 1)
        self.head = nn.Sequential(
            nn.Linear(gru_dim + hidden_size, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, hidden_size // 2),
            nn.ReLU(),
            nn.Linear(hidden_size // 2, 1),
        )

    def forward(self, x, lengths=None):
        z = self.input_proj(x)
        if lengths is None:
            seq_context, _ = self.gru(z)
        else:
            packed = pack_padded_sequence(
                z,
                lengths.detach().cpu(),
                batch_first=True,
                enforce_sorted=False,
            )
            packed_context, _ = self.gru(packed)
            seq_context, _ = pad_packed_sequence(
                packed_context,
                batch_first=True,
                total_length=x.shape[1],
            )
        local_context = self.local_branch(x)
        y = self.head(torch.cat([seq_context, local_context], dim=-1)).squeeze(-1)
        return y


def sequence_loss(batch, pred_scaled, y_min, y_range):
    """
    Combined point, peak, and energy loss.
    """
    y_scaled = batch["y_scaled"].to(DEVICE)
    y_phys = batch["y_phys"].to(DEVICE)
    strain_frac = batch["strain_frac"].to(DEVICE)
    weights = batch["weights"].to(DEVICE)
    mask = batch["mask"].to(DEVICE)
    lengths = batch["lengths"].to(DEVICE)

    mask_f = mask.float()

    point_loss_each = (pred_scaled - y_scaled) ** 2
    point_loss = (point_loss_each * weights * mask_f).sum() / ((weights * mask_f).sum() + 1e-8)

    pred_phys = pred_scaled * y_range + y_min

    peak_losses = []
    energy_losses = []

    for i in range(pred_scaled.shape[0]):
        L = int(lengths[i].item())
        p = pred_phys[i, :L]
        t = y_phys[i, :L]
        x = strain_frac[i, :L]

        peak_losses.append(((torch.max(p) - torch.max(t)) / y_range) ** 2)

        if L >= 2:
            w_pred = torch.abs(integrate_trapz_torch(p, x)) * 1000.0
            w_true = torch.abs(integrate_trapz_torch(t, x)) * 1000.0
            energy_losses.append(((w_pred - w_true) / 50.0) ** 2)

    peak_loss = torch.stack(peak_losses).mean() if peak_losses else pred_scaled.new_tensor(0.0)
    energy_loss = torch.stack(energy_losses).mean() if energy_losses else pred_scaled.new_tensor(0.0)

    total = (
        POINT_LOSS_WEIGHT * point_loss
        + PEAK_LOSS_WEIGHT * peak_loss
        + ENERGY_LOSS_WEIGHT * energy_loss
    )

    return total, {
        "point_loss": float(point_loss.detach().cpu()),
        "peak_loss": float(peak_loss.detach().cpu()),
        "energy_loss": float(energy_loss.detach().cpu()),
        "total_loss": float(total.detach().cpu()),
    }


def run_train_epoch(model, loader, optimizer, y_min, y_range):
    model.train()
    logs = []

    for batch in loader:
        X = batch["X"].to(DEVICE)
        optimizer.zero_grad()
        pred_scaled = model(X, batch["lengths"])
        loss, parts = sequence_loss(batch, pred_scaled, y_min, y_range)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), GRAD_CLIP_NORM)
        optimizer.step()
        logs.append(parts)

    return {k: float(np.mean([d[k] for d in logs])) for k in logs[0]}


def run_eval_epoch(model, loader, y_min, y_range):
    model.eval()
    logs = []
    with torch.no_grad():
        for batch in loader:
            X = batch["X"].to(DEVICE)
            pred_scaled = model(X, batch["lengths"])
            loss, parts = sequence_loss(batch, pred_scaled, y_min, y_range)
            logs.append(parts)
    return {k: float(np.mean([d[k] for d in logs])) for k in logs[0]}


def train_with_validation(model, train_loader, val_loader, max_epochs, patience, lr, ckpt_path, y_min, y_range):
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-6)
    best_val = np.inf
    best_epoch = 0
    patience_counter = 0
    history = []

    for epoch in range(1, max_epochs + 1):
        train_log = run_train_epoch(model, train_loader, optimizer, y_min, y_range)
        val_log = run_eval_epoch(model, val_loader, y_min, y_range)

        row = {"epoch": epoch}
        row.update({f"train_{k}": v for k, v in train_log.items()})
        row.update({f"val_{k}": v for k, v in val_log.items()})
        history.append(row)

        val_score = val_log["total_loss"]
        if val_score < best_val:
            best_val = val_score
            best_epoch = epoch
            patience_counter = 0
            torch.save(
                {
                    "epoch": epoch,
                    "model_state_dict": model.state_dict(),
                    "input_dim": len(FEATURES),
                    "features": FEATURES,
                    "hidden_size": HIDDEN_SIZE,
                    "num_layers": NUM_LAYERS,
                    "dropout": DROPOUT,
                    "bidirectional": BIDIRECTIONAL,
                    "model_type": "GRUSeqRegressor",
                    "loss": {
                        "point": POINT_LOSS_WEIGHT,
                        "peak": PEAK_LOSS_WEIGHT,
                        "energy": ENERGY_LOSS_WEIGHT,
                    },
                    "note": "Validation-search sequence GRU checkpoint.",
                },
                ckpt_path,
            )
        else:
            patience_counter += 1

        if epoch == 1 or epoch % 10 == 0:
            print(
                f"[Val-search] Epoch {epoch:03d} | "
                f"train={train_log['total_loss']:.6f} | "
                f"val={val_log['total_loss']:.6f} | "
                f"best_epoch={best_epoch}"
            )

        if patience_counter >= patience:
            print(f"Early stopping at epoch {epoch}; best_epoch={best_epoch}, best_val={best_val:.6f}")
            break

    return pd.DataFrame(history), best_epoch, best_val


def train_full_data(model, loader, epochs, lr, ckpt_path, y_min, y_range):
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-6)
    history = []

    for epoch in range(1, epochs + 1):
        train_log = run_train_epoch(model, loader, optimizer, y_min, y_range)
        row = {"epoch": epoch}
        row.update(train_log)
        history.append(row)

        if epoch == 1 or epoch % 10 == 0 or epoch == epochs:
            print(
                f"[Full-data] Epoch {epoch:03d}/{epochs:03d} | "
                f"loss={train_log['total_loss']:.6f} | "
                f"point={train_log['point_loss']:.6f} | "
                f"peak={train_log['peak_loss']:.6f} | "
                f"energy={train_log['energy_loss']:.6f}"
            )

    torch.save(
        {
            "epoch": epochs,
            "model_state_dict": model.state_dict(),
            "input_dim": len(FEATURES),
            "features": FEATURES,
            "hidden_size": HIDDEN_SIZE,
            "num_layers": NUM_LAYERS,
            "dropout": DROPOUT,
            "bidirectional": BIDIRECTIONAL,
            "model_type": "GRUSeqRegressor",
            "loss": {
                "point": POINT_LOSS_WEIGHT,
                "peak": PEAK_LOSS_WEIGHT,
                "energy": ENERGY_LOSS_WEIGHT,
            },
            "note": "Final sequence GRU trained on full Dataset.xlsx.",
        },
        ckpt_path,
    )

    return pd.DataFrame(history)


def predict_sequences(model, items, batch_size, scaler_y, n_rows):
    loader = make_loader(items, batch_size=batch_size, shuffle=False)
    model.eval()
    pred_all = np.full(n_rows, np.nan, dtype=np.float32)

    with torch.no_grad():
        for batch in loader:
            X = batch["X"].to(DEVICE)
            pred_scaled = model(X, batch["lengths"]).cpu().numpy()
            lengths = batch["lengths"].numpy()
            row_index = batch["row_index"].numpy()

            pred_phys = scaler_y.inverse_transform(pred_scaled.reshape(-1, 1)).reshape(pred_scaled.shape)

            for i, L in enumerate(lengths):
                idx = row_index[i, :L]
                pred_all[idx] = pred_phys[i, :L]

    return pred_all


# ============================================================
# 6. Descriptor calculation
# ============================================================

def calc_cycle_descriptors(group, stress_col):
    group = group.sort_values("__row_order").copy()
    stress = group[stress_col].to_numpy(dtype=float)
    strain_percent = group[COL_STRAIN].to_numpy(dtype=float)
    strain_fraction = strain_percent / 100.0

    sigma_max = np.nanmax(stress)

    unload = group[group[COL_STATUS] == -1].copy()
    if len(unload) > 0:
        idx_res = unload[stress_col].abs().idxmin()
        epsilon_res = float(unload.loc[idx_res, COL_STRAIN])
        stress_at_res = float(unload.loc[idx_res, stress_col])
    else:
        epsilon_res = np.nan
        stress_at_res = np.nan

    if len(group) >= 2:
        # Two explicit unit conventions are saved to prevent the common 10x
        # mix-up: 1 GPa*percent = 10 MJ/m^3.
        deltaW_GPa_percent = abs(integrate_trapz_np(stress, strain_percent))
        deltaW_MJ_m3 = deltaW_GPa_percent * 10.0
    else:
        deltaW_GPa_percent = np.nan
        deltaW_MJ_m3 = np.nan

    return pd.Series({
        "sigma_max_GPa": sigma_max,
        "epsilon_res_percent": epsilon_res,
        "stress_at_epsilon_res_GPa": stress_at_res,
        "DeltaW_GPa_percent": deltaW_GPa_percent,
        "DeltaW_MJ_m3": deltaW_MJ_m3,
        "n_points": len(group),
    })


def build_descriptors(df, stress_col, suffix):
    cycle_desc = (
        df.groupby(GROUP_KEYS_CYCLE, sort=False)
        .apply(lambda g: calc_cycle_descriptors(g, stress_col))
        .reset_index()
    )

    meta_cols = [COL_DMIN, COL_DMAX, COL_DAVG, COL_GD, COL_GB]
    meta = (
        df.groupby(GROUP_KEYS_CONDITION, sort=False)[meta_cols]
        .first()
        .reset_index()
    )

    cycle_desc = cycle_desc.merge(meta, on=GROUP_KEYS_CONDITION, how="left")

    cycle1 = cycle_desc[cycle_desc[COL_CYCLE] == 1].set_index(GROUP_KEYS_CONDITION)
    cycle8 = cycle_desc[cycle_desc[COL_CYCLE] == 8].set_index(GROUP_KEYS_CONDITION)
    id_desc = meta.set_index(GROUP_KEYS_CONDITION).copy()

    id_desc[f"sigma_max_1_GPa_{suffix}"] = cycle1["sigma_max_GPa"]
    id_desc[f"sigma_max_8_GPa_{suffix}"] = cycle8["sigma_max_GPa"]
    id_desc[f"epsilon_res_1_percent_{suffix}"] = cycle1["epsilon_res_percent"]
    id_desc[f"epsilon_res_8_percent_{suffix}"] = cycle8["epsilon_res_percent"]
    id_desc[f"DeltaW_1_MJ_m3_{suffix}"] = cycle1["DeltaW_MJ_m3"]
    id_desc[f"DeltaW_8_MJ_m3_{suffix}"] = cycle8["DeltaW_MJ_m3"]
    id_desc[f"DeltaW_1_GPa_percent_{suffix}"] = cycle1["DeltaW_GPa_percent"]
    id_desc[f"DeltaW_8_GPa_percent_{suffix}"] = cycle8["DeltaW_GPa_percent"]
    id_desc[f"R_sigma_{suffix}"] = (
        id_desc[f"sigma_max_8_GPa_{suffix}"] /
        id_desc[f"sigma_max_1_GPa_{suffix}"]
    )
    id_desc[f"R_W_{suffix}"] = (
        id_desc[f"DeltaW_8_GPa_percent_{suffix}"] /
        id_desc[f"DeltaW_1_GPa_percent_{suffix}"]
    )
    id_desc[f"W_degradation_rate_{suffix}"] = 1.0 - id_desc[f"R_W_{suffix}"]
    id_desc[f"W_degradation_percent_{suffix}"] = 100.0 * id_desc[f"W_degradation_rate_{suffix}"]
    id_desc[f"Delta_epsilon_res_percent_{suffix}"] = (
        id_desc[f"epsilon_res_8_percent_{suffix}"] -
        id_desc[f"epsilon_res_1_percent_{suffix}"]
    )

    return cycle_desc, id_desc.reset_index()


def add_fsi_columns(df, suffix=""):
    tag = "" if suffix == "" else f"_{suffix}"
    out = df.copy()

    out[f"R_sigma_norm_true{tag}"] = minmax_norm_by_ref(out["R_sigma_true"], out["R_sigma_true"])
    out[f"R_sigma_norm_pred{tag}"] = minmax_norm_by_ref(out["R_sigma_pred"], out["R_sigma_true"])
    out[f"R_W_norm_true{tag}"] = minmax_norm_by_ref(out["R_W_true"], out["R_W_true"])
    out[f"R_W_norm_pred{tag}"] = minmax_norm_by_ref(out["R_W_pred"], out["R_W_true"])
    out[f"epsilon_res_8_norm_true{tag}"] = minmax_norm_by_ref(
        out["epsilon_res_8_percent_true"],
        out["epsilon_res_8_percent_true"],
    )
    out[f"epsilon_res_8_norm_pred{tag}"] = minmax_norm_by_ref(
        out["epsilon_res_8_percent_pred"],
        out["epsilon_res_8_percent_true"],
    )
    out[f"Delta_epsilon_res_norm_true{tag}"] = minmax_norm_by_ref(
        out["Delta_epsilon_res_percent_true"],
        out["Delta_epsilon_res_percent_true"],
    )
    out[f"Delta_epsilon_res_norm_pred{tag}"] = minmax_norm_by_ref(
        out["Delta_epsilon_res_percent_pred"],
        out["Delta_epsilon_res_percent_true"],
    )

    out[f"FSI_final_state_true{tag}"] = (
        out[f"R_sigma_norm_true{tag}"]
        + out[f"R_W_norm_true{tag}"]
        - out[f"epsilon_res_8_norm_true{tag}"]
    )
    out[f"FSI_final_state_pred{tag}"] = (
        out[f"R_sigma_norm_pred{tag}"]
        + out[f"R_W_norm_pred{tag}"]
        - out[f"epsilon_res_8_norm_pred{tag}"]
    )
    out[f"FSI_degradation_true{tag}"] = (
        out[f"R_sigma_norm_true{tag}"]
        + out[f"R_W_norm_true{tag}"]
        - out[f"Delta_epsilon_res_norm_true{tag}"]
    )
    out[f"FSI_degradation_pred{tag}"] = (
        out[f"R_sigma_norm_pred{tag}"]
        + out[f"R_W_norm_pred{tag}"]
        - out[f"Delta_epsilon_res_norm_pred{tag}"]
    )
    out[f"FSI_mean_true{tag}"] = (
        out[f"FSI_final_state_true{tag}"] + out[f"FSI_degradation_true{tag}"]
    ) / 2.0
    out[f"FSI_mean_pred{tag}"] = (
        out[f"FSI_final_state_pred{tag}"] + out[f"FSI_degradation_pred{tag}"]
    ) / 2.0

    return out


def calc_metric(compare_df, true_col, pred_col):
    data = compare_df[[true_col, pred_col]].dropna()
    if len(data) == 0:
        return {
            "descriptor": true_col.replace("_true", ""),
            "n": 0,
            "R2": np.nan,
            "MAE": np.nan,
            "RMSE": np.nan,
            "bias": np.nan,
        }
    err = data[pred_col] - data[true_col]
    return {
        "descriptor": true_col.replace("_true", ""),
        "n": len(data),
        "R2": r2_score(data[true_col], data[pred_col]),
        "MAE": mean_absolute_error(data[true_col], data[pred_col]),
        "RMSE": rmse_score(data[true_col], data[pred_col]),
        "bias": float(err.mean()),
    }


def make_descriptor_outputs(pred_df):
    cycle_true, id_true = build_descriptors(pred_df, "Current_Stress_true", "true")
    cycle_pred, id_pred = build_descriptors(pred_df, "Current_Stress_pred", "pred")

    meta_cols = [COL_ID, COL_T, COL_EMAX, COL_DMIN, COL_DMAX, COL_DAVG, COL_GD, COL_GB]
    true_metric_cols = [c for c in id_true.columns if c.endswith("_true")]
    pred_metric_cols = [c for c in id_pred.columns if c.endswith("_pred")]

    compare = id_true[meta_cols + true_metric_cols].merge(
        id_pred[GROUP_KEYS_CONDITION + pred_metric_cols],
        on=GROUP_KEYS_CONDITION,
        how="left",
    )

    compare = add_fsi_columns(compare, suffix="")

    main = compare[(compare[COL_T] == 400) & (compare[COL_EMAX] == 10)].copy()
    main = add_fsi_columns(main, suffix="local")

    descriptor_pairs_all = [
        ("sigma_max_1_GPa_true", "sigma_max_1_GPa_pred"),
        ("sigma_max_8_GPa_true", "sigma_max_8_GPa_pred"),
        ("epsilon_res_8_percent_true", "epsilon_res_8_percent_pred"),
        ("DeltaW_1_MJ_m3_true", "DeltaW_1_MJ_m3_pred"),
        ("DeltaW_8_MJ_m3_true", "DeltaW_8_MJ_m3_pred"),
        ("R_sigma_true", "R_sigma_pred"),
        ("R_W_true", "R_W_pred"),
        ("Delta_epsilon_res_percent_true", "Delta_epsilon_res_percent_pred"),
        ("FSI_mean_true", "FSI_mean_pred"),
    ]
    descriptor_metrics_all = pd.DataFrame([calc_metric(compare, t, p) for t, p in descriptor_pairs_all])

    descriptor_pairs_main = [
        ("sigma_max_1_GPa_true", "sigma_max_1_GPa_pred"),
        ("sigma_max_8_GPa_true", "sigma_max_8_GPa_pred"),
        ("epsilon_res_8_percent_true", "epsilon_res_8_percent_pred"),
        ("DeltaW_1_MJ_m3_true", "DeltaW_1_MJ_m3_pred"),
        ("DeltaW_8_MJ_m3_true", "DeltaW_8_MJ_m3_pred"),
        ("R_sigma_true", "R_sigma_pred"),
        ("R_W_true", "R_W_pred"),
        ("Delta_epsilon_res_percent_true", "Delta_epsilon_res_percent_pred"),
        ("FSI_mean_true_local", "FSI_mean_pred_local"),
    ]
    descriptor_metrics_main = pd.DataFrame([calc_metric(main, t, p) for t, p in descriptor_pairs_main])

    return cycle_true, cycle_pred, id_true, id_pred, compare, main, descriptor_metrics_all, descriptor_metrics_main


# ============================================================
# 7. Load data
# ============================================================

print("=" * 80)
print("Loading dataset...")
print("Dataset path:", DATA_PATH)

if not DATA_PATH.exists():
    raise FileNotFoundError(f"Cannot find Dataset.xlsx: {DATA_PATH}")

xls = pd.ExcelFile(DATA_PATH)
if PREFERRED_SHEET_NAME in xls.sheet_names:
    sheet_to_read = PREFERRED_SHEET_NAME
else:
    sheet_to_read = xls.sheet_names[0]
    print(f"Preferred sheet {PREFERRED_SHEET_NAME!r} was not found; using first sheet: {sheet_to_read!r}")

df = pd.read_excel(DATA_PATH, sheet_name=sheet_to_read)

if "__row_order" not in df.columns:
    df["__row_order"] = np.arange(len(df))

missing_cols = [c for c in REQUIRED_COLS if c not in df.columns]
if missing_cols:
    raise ValueError(f"Dataset is missing columns: {missing_cols}")

for c in FEATURES + [COL_TARGET]:
    df[c] = pd.to_numeric(df[c], errors="coerce")

df = df.dropna(subset=REQUIRED_COLS).copy()
df = df.sort_values("__row_order").reset_index(drop=True)

print("Rows:", len(df))
print("Unique IDs:", df[COL_ID].nunique())
print("Unique sequences:", df.groupby(GROUP_KEYS_CYCLE).ngroups)
print("Device:", DEVICE)
print("=" * 80)


# ============================================================
# 8. Validation search
# ============================================================

print("\n" + "=" * 80)
print("Step 1: sequence validation search")
print("=" * 80)

set_seed(SEED)

sequence_meta = df[GROUP_KEYS_CYCLE].drop_duplicates().reset_index(drop=True)
gss = GroupShuffleSplit(n_splits=1, test_size=0.2, random_state=SEED)
seq_train_idx, seq_val_idx = next(
    gss.split(sequence_meta, groups=sequence_meta[COL_ID])
)

train_ids = sorted(sequence_meta.iloc[seq_train_idx][COL_ID].unique().tolist())
val_ids = sorted(sequence_meta.iloc[seq_val_idx][COL_ID].unique().tolist())

train_df = df[df[COL_ID].isin(train_ids)].copy()
val_df = df[df[COL_ID].isin(val_ids)].copy()

print("Train IDs for val-search:")
print(train_ids)
print("Val IDs for val-search:")
print(val_ids)

scaler_x_search = StandardScaler()
scaler_y_search = MinMaxScaler()
scaler_x_search.fit(train_df[FEATURES].to_numpy(dtype=np.float32))
scaler_y_search.fit(train_df[[COL_TARGET]].to_numpy(dtype=np.float32))

y_min_search = float(scaler_y_search.data_min_[0])
y_range_search = float(scaler_y_search.data_range_[0])
y_min_search_t = torch.tensor(y_min_search, dtype=torch.float32, device=DEVICE)
y_range_search_t = torch.tensor(y_range_search, dtype=torch.float32, device=DEVICE)

train_items = make_sequence_items(train_df, scaler_x_search, scaler_y_search)
val_items = make_sequence_items(val_df, scaler_x_search, scaler_y_search)

train_loader = make_loader(train_items, batch_size=SEQ_BATCH_SIZE, shuffle=True)
val_loader = make_loader(val_items, batch_size=SEQ_BATCH_SIZE, shuffle=False)

val_model = GRUSeqRegressor(
    input_dim=len(FEATURES),
    hidden_size=HIDDEN_SIZE,
    num_layers=NUM_LAYERS,
    dropout=DROPOUT,
    bidirectional=BIDIRECTIONAL,
).to(DEVICE)

val_ckpt_path = CKPT_DIR / "GRU_sequence_val_search_best.pth"

val_history, best_epoch, best_val_loss = train_with_validation(
    model=val_model,
    train_loader=train_loader,
    val_loader=val_loader,
    max_epochs=MAX_EPOCHS_FOR_VAL_SEARCH,
    patience=PATIENCE,
    lr=LEARNING_RATE,
    ckpt_path=val_ckpt_path,
    y_min=y_min_search_t,
    y_range=y_range_search_t,
)

val_history.to_csv(HISTORY_DIR / "sequence_val_search_history.csv", index=False)

final_epochs = max(1, best_epoch) if FINAL_EPOCHS is None else int(FINAL_EPOCHS)
print(f"Final sequence training epochs = {final_epochs}; reference best_epoch = {best_epoch}")


# ============================================================
# 9. Final full-data sequence training
# ============================================================

print("\n" + "=" * 80)
print("Step 2: train final sequence GRU on full data")
print("=" * 80)

set_seed(SEED)

scaler_x_final = StandardScaler()
scaler_y_final = MinMaxScaler()
scaler_x_final.fit(df[FEATURES].to_numpy(dtype=np.float32))
scaler_y_final.fit(df[[COL_TARGET]].to_numpy(dtype=np.float32))

y_min_final = float(scaler_y_final.data_min_[0])
y_range_final = float(scaler_y_final.data_range_[0])
y_min_final_t = torch.tensor(y_min_final, dtype=torch.float32, device=DEVICE)
y_range_final_t = torch.tensor(y_range_final, dtype=torch.float32, device=DEVICE)

full_items = make_sequence_items(df, scaler_x_final, scaler_y_final)
full_loader = make_loader(full_items, batch_size=SEQ_BATCH_SIZE, shuffle=True)

final_model = GRUSeqRegressor(
    input_dim=len(FEATURES),
    hidden_size=HIDDEN_SIZE,
    num_layers=NUM_LAYERS,
    dropout=DROPOUT,
    bidirectional=BIDIRECTIONAL,
).to(DEVICE)

final_ckpt_path = CKPT_DIR / "GRU_sequence_final_full.pth"

full_history = train_full_data(
    model=final_model,
    loader=full_loader,
    epochs=final_epochs,
    lr=LEARNING_RATE,
    ckpt_path=final_ckpt_path,
    y_min=y_min_final_t,
    y_range=y_range_final_t,
)

full_history.to_csv(HISTORY_DIR / "sequence_full_train_history.csv", index=False)
joblib.dump(scaler_x_final, SCALER_DIR / "scaler_x_sequence_final.pkl")
joblib.dump(scaler_y_final, SCALER_DIR / "scaler_y_sequence_final.pkl")


# ============================================================
# 10. Predict all existing curves
# ============================================================

print("\n" + "=" * 80)
print("Step 3: predict all existing sequences")
print("=" * 80)

y_pred = predict_sequences(
    model=final_model,
    items=full_items,
    batch_size=SEQ_BATCH_SIZE,
    scaler_y=scaler_y_final,
    n_rows=len(df),
)
y_true = df[COL_TARGET].to_numpy(dtype=float)

full_r2 = r2_score(y_true, y_pred)
full_mae = mean_absolute_error(y_true, y_pred)
full_rmse = rmse_score(y_true, y_pred)

print("\nFull-data sequence reconstruction metrics:")
print(f"R2   = {full_r2:.6f}")
print(f"MAE  = {full_mae:.6f} GPa")
print(f"RMSE = {full_rmse:.6f} GPa")

metrics_df = pd.DataFrame([{
    "model": "GRU_sequence_final_v3_packed_bestepoch_full_data",
    "n_rows": len(df),
    "n_sequences": len(full_items),
    "n_IDs": df[COL_ID].nunique(),
    "features": ",".join(FEATURES),
    "reference_best_epoch_from_val_search": best_epoch,
    "final_training_epochs": final_epochs,
    "best_val_loss": best_val_loss,
    "point_loss_weight": POINT_LOSS_WEIGHT,
    "peak_loss_weight": PEAK_LOSS_WEIGHT,
    "energy_loss_weight": ENERGY_LOSS_WEIGHT,
    "hidden_size": HIDDEN_SIZE,
    "num_layers": NUM_LAYERS,
    "bidirectional": BIDIRECTIONAL,
    "R2_in_sample": full_r2,
    "MAE_GPa_in_sample": full_mae,
    "RMSE_GPa_in_sample": full_rmse,
    "note": "Sequence full-data reconstruction; not OOF and not external test.",
}])
metrics_df.to_csv(OUTPUT_DIR / "sequence_reconstruction_metrics.csv", index=False)


# ============================================================
# 11. Save point-level predictions
# ============================================================

pred_df = df.copy()
pred_df["source"] = "sequence_full_data_reconstruction"
pred_df["Current_Stress_true"] = y_true
pred_df["Current_Stress_pred"] = y_pred
pred_df["abs_error"] = np.abs(pred_df["Current_Stress_true"] - pred_df["Current_Stress_pred"])

front_cols = [
    COL_ID,
    COL_DMIN,
    COL_DMAX,
    COL_DAVG,
    COL_GD,
    COL_GB,
    COL_EMAX,
    COL_T,
    COL_CYCLE,
    COL_STATUS,
    COL_STRAIN,
    "Current_Stress_true",
    "Current_Stress_pred",
    "abs_error",
    "source",
    "__row_order",
]
other_cols = [c for c in pred_df.columns if c not in front_cols]
pred_df = pred_df[front_cols + other_cols]

csv_path = PRED_DIR / "gru_sequence_full_predictions_all.csv"
xlsx_path = PRED_DIR / "gru_sequence_full_predictions_all.xlsx"

pred_df.to_csv(csv_path, index=False)
with pd.ExcelWriter(xlsx_path, engine="openpyxl") as writer:
    pred_df.to_excel(writer, sheet_name="full_predictions", index=False)
    metrics_df.to_excel(writer, sheet_name="full_metrics", index=False)

print("\nSaved sequence full-data predictions:")
print(csv_path)
print(xlsx_path)


# ============================================================
# 12. Descriptor-level metrics
# ============================================================

print("\n" + "=" * 80)
print("Step 4: calculate sequence descriptor metrics")
print("=" * 80)

(
    cycle_true,
    cycle_pred,
    id_true,
    id_pred,
    compare,
    main,
    descriptor_metrics_all,
    descriptor_metrics_main,
) = make_descriptor_outputs(pred_df)

desc_path = OUTPUT_DIR / "sequence_cyclic_descriptors.xlsx"
with pd.ExcelWriter(desc_path, engine="openpyxl") as writer:
    cycle_true.to_excel(writer, sheet_name="cycle_level_true", index=False)
    cycle_pred.to_excel(writer, sheet_name="cycle_level_pred", index=False)
    id_true.to_excel(writer, sheet_name="ID_condition_true", index=False)
    id_pred.to_excel(writer, sheet_name="ID_condition_pred", index=False)
    compare.to_excel(writer, sheet_name="true_vs_pred_metrics_all", index=False)
    descriptor_metrics_all.to_excel(writer, sheet_name="descriptor_accuracy_all", index=False)
    main.to_excel(writer, sheet_name="main_400K_10pct", index=False)
    descriptor_metrics_main.to_excel(writer, sheet_name="descriptor_accuracy_main", index=False)

print("\nDescriptor-level metrics, all data:")
print(descriptor_metrics_all.to_string(index=False))

print("\nDescriptor-level metrics, main condition 400 K, 10%:")
print(descriptor_metrics_main.to_string(index=False))

print("\nSaved descriptor workbook:")
print(desc_path)


# ============================================================
# 13. Parity plot
# ============================================================

plt.figure(figsize=(6, 6))
plt.scatter(y_true, y_pred, s=6, alpha=0.35)
vmin = min(np.nanmin(y_true), np.nanmin(y_pred))
vmax = max(np.nanmax(y_true), np.nanmax(y_pred))
plt.plot([vmin, vmax], [vmin, vmax], "k--", linewidth=1.2)
plt.xlabel("MD stress, true (GPa)")
plt.ylabel("Sequence GRU prediction (GPa)")
plt.title(f"Sequence full-data reconstruction: R2={full_r2:.4f}, MAE={full_mae:.4f}, RMSE={full_rmse:.4f}")
plt.tight_layout()
fig_path = FIG_DIR / "sequence_full_reconstruction_parity.png"
plt.savefig(fig_path, dpi=300)
plt.close()

print("\nSaved figure:")
print(fig_path)
print("\nAll done.")
