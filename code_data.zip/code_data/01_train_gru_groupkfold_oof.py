# -*- coding: utf-8 -*-
"""
03_train_gru_groupkfold_third_style.py

功能：
    按第三篇论文的训练逻辑进行 5-fold GroupKFold 训练。

核心逻辑：
    1. 按 ID 分组做 GroupKFold；
    2. 每一折直接得到 train_df 和 val_df；
    3. 使用 train_df 训练 GRU；
    4. 使用 val_df 选择该折 best epoch；
    5. 最后仍在 val_df 上计算 R2、MAE、RMSE；
    6. 保存所有 fold 的预测结果，并保存 R2 最好的 fold 模型。

说明：
    这版是第三篇风格的 GroupKFold CV。
    val_df 同时用于 best epoch 选择和最终评分。
    因此结果通常会比严格 nested OOF 更高。
"""

from pathlib import Path
import json
import random
import copy
import warnings

import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader

from sklearn.model_selection import GroupKFold
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error


warnings.filterwarnings("ignore")


# ============================================================
# 1. 路径设置
# ============================================================

BASE_DIR = Path(r"E:\TiNi_4_code")
DATA_PATH = BASE_DIR / "Dataset.xlsx"
SHEET_NAME = 0

OUTPUT_DIR = BASE_DIR / "gru_oof_results_10features_third_style"
CKPT_DIR = OUTPUT_DIR / "checkpoints"
SCALER_DIR = OUTPUT_DIR / "scalers"
HISTORY_DIR = OUTPUT_DIR / "histories"
PRED_DIR = OUTPUT_DIR / "predictions"
FIG_DIR = OUTPUT_DIR / "figures"

for d in [OUTPUT_DIR, CKPT_DIR, SCALER_DIR, HISTORY_DIR, PRED_DIR, FIG_DIR]:
    d.mkdir(parents=True, exist_ok=True)


# ============================================================
# 2. 随机种子与设备
# ============================================================

SEED = 42


def set_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


set_seed(SEED)

torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# ============================================================
# 3. 训练参数
# ============================================================

N_SPLITS = 5

BATCH_SIZE = 512
EPOCHS = 300
LEARNING_RATE = 1e-3

HIDDEN_SIZE = 256
NUM_LAYERS = 2
DROPOUT = 0.1


# ============================================================
# 4. 列名和特征
# ============================================================

COL_ID = "ID"

COL_DMIN = "d_min (nm)"
COL_DMAX = "d_max (nm)"
COL_DAVG = "Davg"
COL_GD = "gd"
COL_GB = "GB_frac0"

COL_EMAX = "Max Strain(%)"
COL_T = "T (K)"

COL_CYCLE = "cycle_n"
COL_STATUS = "Load_Status"
COL_STRAIN = "Current_Strain"

COL_TARGET = "Current_Stress"

FEATURES = [
    COL_DMIN,
    COL_DMAX,
    COL_DAVG,
    COL_GD,
    COL_GB,
    COL_EMAX,
    COL_T,
    COL_CYCLE,
    COL_STATUS,
    COL_STRAIN,
]

REQUIRED_COLS = [COL_ID] + FEATURES + [COL_TARGET]


# ============================================================
# 5. 模型和工具函数
# ============================================================

def rmse_score(y_true, y_pred):
    return np.sqrt(mean_squared_error(y_true, y_pred))


class GRURegressor(nn.Module):
    def __init__(
        self,
        input_dim: int,
        hidden_size: int = 128,
        num_layers: int = 2,
        dropout: float = 0.2,
    ):
        super().__init__()

        self.gru = nn.GRU(
            input_size=input_dim,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0.0,
        )

        self.fc = nn.Sequential(
            nn.Linear(hidden_size, 64),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Linear(32, 1),
        )

    def forward(self, x):
        out, _ = self.gru(x)
        last = out[:, -1, :]
        y = self.fc(last)
        return y


def make_loader(X, y, batch_size, shuffle):
    X_tensor = torch.tensor(X, dtype=torch.float32)
    y_tensor = torch.tensor(y, dtype=torch.float32)

    dataset = TensorDataset(X_tensor, y_tensor)

    loader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=0,
        pin_memory=False,
    )

    return loader


def to_gru_input(X_scaled):
    return X_scaled.reshape(X_scaled.shape[0], 1, X_scaled.shape[1])


def clone_state_dict_to_cpu(model):
    return {
        k: v.detach().cpu().clone()
        for k, v in model.state_dict().items()
    }


def train_one_fold_third_style(
    fold,
    model,
    train_loader,
    val_loader,
    epochs,
    lr,
):
    """
    第三篇风格：
        train_loader 训练；
        val_loader 用于记录 val_loss，并选择 best epoch；
        训练固定 300 epoch，不用 scheduler，不用内部再划分。
    """
    criterion = nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)

    best_val_loss = np.inf
    best_epoch = 0
    best_state = None

    history = []

    for epoch in range(1, epochs + 1):
        # -------------------------
        # Train
        # -------------------------
        model.train()
        train_losses = []

        for xb, yb in train_loader:
            xb = xb.to(DEVICE)
            yb = yb.to(DEVICE)

            optimizer.zero_grad()
            pred = model(xb)
            loss = criterion(pred, yb)
            loss.backward()
            optimizer.step()

            train_losses.append(loss.item())

        train_loss = float(np.mean(train_losses))

        # -------------------------
        # Validation
        # -------------------------
        model.eval()
        val_losses = []

        with torch.no_grad():
            for xb, yb in val_loader:
                xb = xb.to(DEVICE)
                yb = yb.to(DEVICE)

                pred = model(xb)
                loss = criterion(pred, yb)

                val_losses.append(loss.item())

        val_loss = float(np.mean(val_losses))

        history.append({
            "fold": fold,
            "epoch": epoch,
            "train_loss": train_loss,
            "val_loss": val_loss,
        })

        if val_loss < best_val_loss:
            best_val_loss = val_loss
            best_epoch = epoch
            best_state = clone_state_dict_to_cpu(model)

        if epoch == 1 or epoch % 10 == 0 or epoch == epochs:
            print(
                f"Fold {fold} | Epoch {epoch:03d}/{epochs:03d} | "
                f"Train loss = {train_loss:.6f} | "
                f"Val loss = {val_loss:.6f} | "
                f"Best epoch = {best_epoch}"
            )

    if best_state is None:
        raise RuntimeError(f"Fold {fold}: best_state is None.")

    model.load_state_dict(best_state)

    return pd.DataFrame(history), best_epoch, best_val_loss, model


def predict_model(model, X_gru, batch_size=512):
    model.eval()

    dummy_y = np.zeros((len(X_gru), 1), dtype=np.float32)
    loader = make_loader(X_gru, dummy_y, batch_size=batch_size, shuffle=False)

    preds = []

    with torch.no_grad():
        for xb, _ in loader:
            xb = xb.to(DEVICE)
            pred = model(xb)
            preds.append(pred.cpu().numpy())

    return np.vstack(preds)


# ============================================================
# 6. 读取数据
# ============================================================

print("=" * 80)
print("Loading dataset...")
print("Dataset path:", DATA_PATH)

if not DATA_PATH.exists():
    raise FileNotFoundError(f"Dataset.xlsx not found: {DATA_PATH}")

df = pd.read_excel(DATA_PATH, sheet_name=SHEET_NAME)

if "__row_order" not in df.columns:
    df["__row_order"] = np.arange(len(df))

missing_cols = [c for c in REQUIRED_COLS if c not in df.columns]
if missing_cols:
    raise ValueError(f"Missing required columns: {missing_cols}")

for c in FEATURES + [COL_TARGET]:
    df[c] = pd.to_numeric(df[c], errors="coerce")

df = df.dropna(subset=REQUIRED_COLS).copy()
df = df.sort_values("__row_order").reset_index(drop=True)

print("Data loaded successfully.")
print("Rows:", len(df))
print("Unique IDs:", df[COL_ID].nunique())
print("Features:")
for f in FEATURES:
    print("  -", f)
print("Target:", COL_TARGET)
print("Device:", DEVICE)
print("=" * 80)


# ============================================================
# 7. GroupKFold 第三篇风格训练
# ============================================================

X_raw = df[FEATURES].values.astype(np.float32)
y_raw = df[[COL_TARGET]].values.astype(np.float32)
groups = df[COL_ID].values

gkf = GroupKFold(n_splits=N_SPLITS)

all_oof_rows = []
all_metrics = []
fold_val_ids = {}

best_fold_r2 = -np.inf
best_fold = None

for fold, (train_idx, val_idx) in enumerate(
    gkf.split(X_raw, y_raw, groups=groups),
    start=1,
):
    print("\n" + "=" * 80)
    print(f"Fold {fold}/{N_SPLITS}")
    print("=" * 80)

    set_seed(SEED + fold)

    train_df = df.iloc[train_idx].copy()
    val_df = df.iloc[val_idx].copy()

    train_ids = sorted(train_df[COL_ID].unique().tolist())
    val_ids = sorted(val_df[COL_ID].unique().tolist())

    fold_val_ids[f"fold_{fold}"] = val_ids

    print("Train IDs:", train_ids)
    print("Val IDs:", val_ids)
    print("Train rows:", len(train_df))
    print("Val rows:", len(val_df))

    # -------------------------
    # scaler 只在 train 上 fit
    # -------------------------
    scaler_x = StandardScaler()
    scaler_y = MinMaxScaler()

    X_train = train_df[FEATURES].values.astype(np.float32)
    y_train = train_df[[COL_TARGET]].values.astype(np.float32)

    X_val = val_df[FEATURES].values.astype(np.float32)
    y_val = val_df[[COL_TARGET]].values.astype(np.float32)

    X_train_scaled = scaler_x.fit_transform(X_train)
    X_val_scaled = scaler_x.transform(X_val)

    y_train_scaled = scaler_y.fit_transform(y_train)
    y_val_scaled = scaler_y.transform(y_val)

    X_train_gru = to_gru_input(X_train_scaled)
    X_val_gru = to_gru_input(X_val_scaled)

    train_loader = make_loader(
        X_train_gru,
        y_train_scaled,
        batch_size=BATCH_SIZE,
        shuffle=True,
    )

    val_loader = make_loader(
        X_val_gru,
        y_val_scaled,
        batch_size=BATCH_SIZE,
        shuffle=False,
    )

    model = GRURegressor(
        input_dim=len(FEATURES),
        hidden_size=HIDDEN_SIZE,
        num_layers=NUM_LAYERS,
        dropout=DROPOUT,
    ).to(DEVICE)

    history_df, best_epoch, best_val_loss, model = train_one_fold_third_style(
        fold=fold,
        model=model,
        train_loader=train_loader,
        val_loader=val_loader,
        epochs=EPOCHS,
        lr=LEARNING_RATE,
    )

    history_df.to_csv(
        HISTORY_DIR / f"train_history_fold{fold}.csv",
        index=False,
    )

    # -------------------------
    # 在 val_df 上评分
    # -------------------------
    y_pred_scaled = predict_model(
        model,
        X_val_gru,
        batch_size=BATCH_SIZE,
    )

    y_pred = scaler_y.inverse_transform(y_pred_scaled).reshape(-1)
    y_true = y_val.reshape(-1)

    fold_r2 = r2_score(y_true, y_pred)
    fold_mae = mean_absolute_error(y_true, y_pred)
    fold_rmse = rmse_score(y_true, y_pred)

    print(
        f"Fold {fold} val metrics | "
        f"R2 = {fold_r2:.6f}, "
        f"MAE = {fold_mae:.6f} GPa, "
        f"RMSE = {fold_rmse:.6f} GPa"
    )

    all_metrics.append({
        "fold": fold,
        "val_ids": ",".join(val_ids),
        "n_train_rows": len(train_df),
        "n_val_rows": len(val_df),
        "best_epoch": best_epoch,
        "best_val_loss_scaled": best_val_loss,
        "R2": fold_r2,
        "MAE_GPa": fold_mae,
        "RMSE_GPa": fold_rmse,
        "batch_size": BATCH_SIZE,
        "epochs": EPOCHS,
        "learning_rate": LEARNING_RATE,
        "hidden_size": HIDDEN_SIZE,
        "num_layers": NUM_LAYERS,
        "dropout": DROPOUT,
    })

    # -------------------------
    # 保存该 fold 模型和 scaler
    # -------------------------
    ckpt_path = CKPT_DIR / f"GRU_fold{fold}_best.pth"

    torch.save(
        {
            "fold": fold,
            "epoch": best_epoch,
            "model_state_dict": model.state_dict(),
            "input_dim": len(FEATURES),
            "features": FEATURES,
            "hidden_size": HIDDEN_SIZE,
            "num_layers": NUM_LAYERS,
            "dropout": DROPOUT,
            "batch_size": BATCH_SIZE,
            "learning_rate": LEARNING_RATE,
            "best_val_loss_scaled": best_val_loss,
            "train_ids": train_ids,
            "val_ids": val_ids,
        },
        ckpt_path,
    )

    joblib.dump(scaler_x, SCALER_DIR / f"scaler_x_fold{fold}.pkl")
    joblib.dump(scaler_y, SCALER_DIR / f"scaler_y_fold{fold}.pkl")

    # 保存全体预测
    pred_df = val_df.copy()
    pred_df["fold"] = fold
    pred_df["Current_Stress_true"] = y_true
    pred_df["Current_Stress_pred"] = y_pred
    pred_df["abs_error"] = np.abs(
        pred_df["Current_Stress_true"] - pred_df["Current_Stress_pred"]
    )

    all_oof_rows.append(pred_df)

    # 保存 R2 最好的 fold，模仿第三篇 best_cv
    if fold_r2 > best_fold_r2:
        best_fold_r2 = fold_r2
        best_fold = fold

        torch.save(
            model.state_dict(),
            CKPT_DIR / "GRU_best_cv.pth",
        )
        joblib.dump(
            scaler_x,
            SCALER_DIR / "scaler_x_GRU_best_cv.pkl",
        )
        joblib.dump(
            scaler_y,
            SCALER_DIR / "scaler_y_GRU_best_cv.pkl",
        )
        val_df.to_excel(
            PRED_DIR / "val_best_cv_GRU.xlsx",
            index=False,
        )


# ============================================================
# 8. 合并 OOF/val predictions 并保存
# ============================================================

oof_df = pd.concat(all_oof_rows, axis=0, ignore_index=True)
oof_df = oof_df.sort_values("__row_order").reset_index(drop=True)

y_true_all = oof_df["Current_Stress_true"].values
y_pred_all = oof_df["Current_Stress_pred"].values

overall_r2 = r2_score(y_true_all, y_pred_all)
overall_mae = mean_absolute_error(y_true_all, y_pred_all)
overall_rmse = rmse_score(y_true_all, y_pred_all)

metrics_df = pd.DataFrame(all_metrics)

overall_row = pd.DataFrame([{
    "fold": "overall",
    "val_ids": "all",
    "n_train_rows": np.nan,
    "n_val_rows": len(oof_df),
    "best_epoch": np.nan,
    "best_val_loss_scaled": np.nan,
    "R2": overall_r2,
    "MAE_GPa": overall_mae,
    "RMSE_GPa": overall_rmse,
    "batch_size": BATCH_SIZE,
    "epochs": EPOCHS,
    "learning_rate": LEARNING_RATE,
    "hidden_size": HIDDEN_SIZE,
    "num_layers": NUM_LAYERS,
    "dropout": DROPOUT,
}])

metrics_out = pd.concat(
    [metrics_df, overall_row],
    ignore_index=True,
)

metrics_out.to_csv(
    OUTPUT_DIR / "cv_metrics.csv",
    index=False,
)

with open(OUTPUT_DIR / "fold_val_ids.json", "w", encoding="utf-8") as f:
    json.dump(fold_val_ids, f, indent=4, ensure_ascii=False)


front_cols = [
    COL_ID,
    COL_DMIN,
    COL_DMAX,
    COL_DAVG,
    COL_GD,
    COL_GB,
    COL_EMAX,
    COL_T,
    COL_CYCLE,
    COL_STATUS,
    COL_STRAIN,
    "Current_Stress_true",
    "Current_Stress_pred",
    "abs_error",
    "fold",
    "__row_order",
]

other_cols = [c for c in oof_df.columns if c not in front_cols]
oof_df = oof_df[front_cols + other_cols]

csv_path = PRED_DIR / "gru_oof_predictions_all.csv"
xlsx_path = PRED_DIR / "gru_oof_predictions_all.xlsx"

oof_df.to_csv(csv_path, index=False)

with pd.ExcelWriter(xlsx_path, engine="openpyxl") as writer:
    oof_df.to_excel(writer, sheet_name="oof_predictions", index=False)
    metrics_out.to_excel(writer, sheet_name="cv_metrics", index=False)

print("\n" + "=" * 80)
print("Overall GroupKFold metrics, third-paper style")
print("=" * 80)
print(f"R2   = {overall_r2:.6f}")
print(f"MAE  = {overall_mae:.6f} GPa")
print(f"RMSE = {overall_rmse:.6f} GPa")
print(f"Best fold = {best_fold}, Best fold R2 = {best_fold_r2:.6f}")

print("\nSaved predictions:")
print(csv_path)
print(xlsx_path)

print("\nSaved cv metrics:")
print(OUTPUT_DIR / "cv_metrics.csv")


# ============================================================
# 9. 保存 parity plot
# ============================================================

plt.figure(figsize=(6, 6))
plt.scatter(y_true_all, y_pred_all, s=6, alpha=0.35)

vmin = min(np.min(y_true_all), np.min(y_pred_all))
vmax = max(np.max(y_true_all), np.max(y_pred_all))

plt.plot([vmin, vmax], [vmin, vmax], "k--", linewidth=1.2)

plt.xlabel("MD stress, true (GPa)")
plt.ylabel("GRU prediction (GPa)")
plt.title(
    f"GroupKFold prediction, third-paper style\n"
    f"R2={overall_r2:.4f}, "
    f"MAE={overall_mae:.4f}, "
    f"RMSE={overall_rmse:.4f}"
)

plt.tight_layout()

fig_path = FIG_DIR / "parity_current_stress_third_style.png"
plt.savefig(fig_path, dpi=300)
plt.close()

print("\nSaved figure:")
print(fig_path)

print("\nAll done.")