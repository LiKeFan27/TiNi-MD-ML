# -*- coding: utf-8 -*-
"""
Feature-group ablation analysis for the point-wise GRU model.

Purpose:
    Compare the contribution of different feature groups to GRU stress prediction.

Validation strategy:
    5-fold GroupKFold grouped by Model ID.
    Samples from the same MD model will not appear in both training and validation sets.

Output:
    E:\\TiNi_4_code\\results_ablation\\ablation_results_by_fold.csv
    E:\\TiNi_4_code\\results_ablation\\ablation_summary.csv
    E:\\TiNi_4_code\\results_ablation\\ablation_summary.png
    E:\\TiNi_4_code\\results_ablation\\ablation_summary.pdf
"""

from pathlib import Path
import random
import warnings

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset

from sklearn.model_selection import GroupKFold
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error


warnings.filterwarnings("ignore")


# ============================================================
# 1. Paths
# ============================================================

BASE_DIR = Path(r"E:\TiNi_4_code")
DATA_PATH = BASE_DIR / "Dataset.xlsx"
PREFERRED_SHEET_NAME = "全部"

OUTPUT_DIR = BASE_DIR / "results_ablation"
BY_FOLD_CSV = OUTPUT_DIR / "ablation_results_by_fold.csv"
SUMMARY_CSV = OUTPUT_DIR / "ablation_summary.csv"
SUMMARY_PNG = OUTPUT_DIR / "ablation_summary.png"
SUMMARY_PDF = OUTPUT_DIR / "ablation_summary.pdf"


# ============================================================
# 2. Reproducibility and hyperparameters
# ============================================================

SEED = 42
N_SPLITS = 5

BATCH_SIZE = 512
EPOCHS = 300
PATIENCE = 30
LEARNING_RATE = 1e-3

HIDDEN_SIZE = 128
NUM_LAYERS = 2

# 这里建议与你论文正文和原始 GRU-CV 设置保持一致
# 如果你原始 GRU-CV 用的是 0.20，就把这里改成 0.20
# 如果正文写的是 0.25，就保持 0.25
DROPOUT = 0.25

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def set_seed(seed: int) -> None:
    """Set random seed for reproducibility."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)

    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


set_seed(SEED)


# ============================================================
# 3. Columns and feature groups
# ============================================================

COL_GROUP = "Model ID"
COL_TARGET = "st"

ALL_FEATURES = [
    "dmin",
    "dmax",
    "gd",
    "fGB",
    "davg",
    "emax",
    "T",
    "N",
    "Sload",
    "et",
]

ABLATION_GROUPS = [
    (
        "Full",
        ALL_FEATURES,
    ),
    (
        "Without structure",
        [f for f in ALL_FEATURES if f not in ["dmin", "dmax", "gd", "fGB", "davg"]],
    ),
    (
        "Without loading",
        [f for f in ALL_FEATURES if f not in ["emax", "T", "Sload"]],
    ),
    (
        "Without cycle history",
        [f for f in ALL_FEATURES if f != "N"],
    ),
    (
        "Without current strain",
        [f for f in ALL_FEATURES if f != "et"],
    ),
]

# 兼容你之前数据表可能使用的列名
COLUMN_ALIASES = {
    # Group column
    "ID": COL_GROUP,
    "Model_ID": COL_GROUP,
    "model_id": COL_GROUP,
    "ModelID": COL_GROUP,

    # Target column
    "Current_Stress": COL_TARGET,
    "Stress": COL_TARGET,
    "stress": COL_TARGET,
    "Current Stress": COL_TARGET,
    "sigma": COL_TARGET,

    # Structure features
    "d_min (nm)": "dmin",
    "dmin (nm)": "dmin",
    "d_min": "dmin",
    "Dmin": "dmin",

    "d_max (nm)": "dmax",
    "dmax (nm)": "dmax",
    "d_max": "dmax",
    "Dmax": "dmax",

    "Gradient Degree": "gd",
    "Gradient degree": "gd",
    "gradient_degree": "gd",

    "GB_frac0": "fGB",
    "FGB": "fGB",
    "f_GB": "fGB",
    "GB fraction": "fGB",
    "Initial Grain Boundary Fraction": "fGB",

    "Davg": "davg",
    "D_avg": "davg",
    "davg (nm)": "davg",
    "Average Grain Size": "davg",
    "Average Grain Size (nm)": "davg",

    # Loading and state features
    "Max Strain(%)": "emax",
    "Max Strain": "emax",
    "Max_Strain": "emax",
    "emax (%)": "emax",
    "Max Strain Amplitude": "emax",

    "T (K)": "T",
    "Temperature": "T",
    "Temperature (K)": "T",

    "cycle_n": "N",
    "Cycle": "N",
    "cycle": "N",
    "Cycle Index": "N",

    "Load_Status": "Sload",
    "Loading State": "Sload",
    "S_load": "Sload",

    "Current_Strain": "et",
    "Current Strain": "et",
    "strain": "et",
    "Instantaneous Strain": "et",
}


# ============================================================
# 4. GRU model
# ============================================================

class GRURegressor(nn.Module):
    def __init__(
        self,
        input_dim: int,
        hidden_size: int = 128,
        num_layers: int = 2,
        dropout: float = 0.25,
    ):
        super().__init__()

        self.gru = nn.GRU(
            input_size=input_dim,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0.0,
        )

        self.fc = nn.Sequential(
            nn.Linear(hidden_size, 64),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Linear(32, 1),
        )

    def forward(self, x):
        # x shape: [batch_size, seq_len, input_dim]
        out, _ = self.gru(x)
        last = out[:, -1, :]
        return self.fc(last)


# ============================================================
# 5. Helper functions
# ============================================================

def rmse_score(y_true, y_pred) -> float:
    return float(np.sqrt(mean_squared_error(y_true, y_pred)))


def to_gru_input(X: np.ndarray) -> np.ndarray:
    """
    Convert point-wise features to GRU input.

    Original shape:
        [n_samples, n_features]

    GRU shape:
        [n_samples, seq_len=1, n_features]
    """
    return X.reshape(X.shape[0], 1, X.shape[1]).astype(np.float32)


def make_loader(X, y, batch_size: int, shuffle: bool) -> DataLoader:
    dataset = TensorDataset(
        torch.tensor(X, dtype=torch.float32),
        torch.tensor(y, dtype=torch.float32),
    )

    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=0,
        pin_memory=torch.cuda.is_available(),
    )


def clone_state_dict_to_cpu(model: nn.Module) -> dict:
    return {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}


def load_dataset() -> pd.DataFrame:
    if not DATA_PATH.exists():
        raise FileNotFoundError(f"Dataset not found: {DATA_PATH}")

    xls = pd.ExcelFile(DATA_PATH)

    if PREFERRED_SHEET_NAME in xls.sheet_names:
        sheet_name = PREFERRED_SHEET_NAME
    else:
        sheet_name = xls.sheet_names[0]
        print(
            f"Preferred sheet {PREFERRED_SHEET_NAME!r} was not found. "
            f"Using first sheet: {sheet_name!r}"
        )

    df = pd.read_excel(DATA_PATH, sheet_name=sheet_name)

    # Rename columns according to aliases
    rename_dict = {k: v for k, v in COLUMN_ALIASES.items() if k in df.columns}
    df = df.rename(columns=rename_dict)

    required_cols = [COL_GROUP, COL_TARGET] + ALL_FEATURES
    missing_cols = [c for c in required_cols if c not in df.columns]

    if missing_cols:
        print("\nCurrent columns in Dataset.xlsx:")
        print(list(df.columns))
        raise ValueError(
            f"Missing required columns after alias normalization: {missing_cols}"
        )

    # Convert numeric columns
    for col in ALL_FEATURES + [COL_TARGET]:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    # Drop missing rows
    before = len(df)
    df = df.dropna(subset=required_cols).reset_index(drop=True)
    after = len(df)

    if after < before:
        print(f"Dropped {before - after} rows due to missing values.")

    n_groups = df[COL_GROUP].nunique()
    if n_groups < N_SPLITS:
        raise ValueError(
            f"GroupKFold needs at least {N_SPLITS} unique groups, "
            f"but found only {n_groups}."
        )

    return df


def train_one_fold(
    model: nn.Module,
    train_loader: DataLoader,
    val_loader: DataLoader,
    epochs: int,
    lr: float,
    patience: int,
):
    criterion = nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)

    best_val_loss = np.inf
    best_epoch = 0
    best_state = None
    wait = 0

    for epoch in range(1, epochs + 1):
        model.train()

        for xb, yb in train_loader:
            xb = xb.to(DEVICE)
            yb = yb.to(DEVICE)

            optimizer.zero_grad()
            pred = model(xb)
            loss = criterion(pred, yb)
            loss.backward()
            optimizer.step()

        model.eval()
        val_losses = []

        with torch.no_grad():
            for xb, yb in val_loader:
                xb = xb.to(DEVICE)
                yb = yb.to(DEVICE)

                pred = model(xb)
                val_loss = criterion(pred, yb).item()
                val_losses.append(val_loss)

        mean_val_loss = float(np.mean(val_losses))

        if mean_val_loss < best_val_loss:
            best_val_loss = mean_val_loss
            best_epoch = epoch
            best_state = clone_state_dict_to_cpu(model)
            wait = 0
        else:
            wait += 1

        if epoch == 1 or epoch % 50 == 0 or epoch == epochs:
            print(
                f"Epoch {epoch:03d}/{epochs:03d} | "
                f"val_loss={mean_val_loss:.6f} | "
                f"best_epoch={best_epoch}"
            )

        if wait >= patience:
            print(f"Early stopping at epoch {epoch}. Best epoch = {best_epoch}.")
            break

    if best_state is None:
        raise RuntimeError("Training failed: best_state was not saved.")

    model.load_state_dict(best_state)
    model.to(DEVICE)

    return model, best_epoch, best_val_loss


def predict_model(model: nn.Module, X: np.ndarray, batch_size: int) -> np.ndarray:
    model.eval()

    dummy_y = np.zeros((len(X), 1), dtype=np.float32)
    loader = make_loader(X, dummy_y, batch_size=batch_size, shuffle=False)

    preds = []

    with torch.no_grad():
        for xb, _ in loader:
            xb = xb.to(DEVICE)
            pred = model(xb).detach().cpu().numpy()
            preds.append(pred)

    return np.vstack(preds).reshape(-1)


# ============================================================
# 6. Ablation analysis
# ============================================================

def run_ablation(df: pd.DataFrame) -> pd.DataFrame:
    groups = df[COL_GROUP].to_numpy()
    y_all = df[COL_TARGET].to_numpy(dtype=np.float32)

    # Keep exactly the same folds for all ablation cases
    gkf = GroupKFold(n_splits=N_SPLITS)
    split_indices = list(gkf.split(df, y_all, groups=groups))

    rows = []

    for ablation_order, (ablation_name, features) in enumerate(ABLATION_GROUPS, start=1):
        print("\n" + "=" * 90)
        print(f"Ablation {ablation_order}/{len(ABLATION_GROUPS)}: {ablation_name}")
        print("Features:", ", ".join(features))
        print("=" * 90)

        X_all = df[features].to_numpy(dtype=np.float32)

        for fold, (train_idx, val_idx) in enumerate(split_indices, start=1):
            print(f"\n{ablation_name} | Fold {fold}/{N_SPLITS}")

            # Different but reproducible seed for each fold
            set_seed(SEED + fold)

            X_train_raw = X_all[train_idx]
            X_val_raw = X_all[val_idx]

            y_train = y_all[train_idx].reshape(-1, 1)
            y_val = y_all[val_idx]

            train_groups = df.iloc[train_idx][COL_GROUP].unique()
            val_groups = df.iloc[val_idx][COL_GROUP].unique()

            print(f"Train groups: {len(train_groups)} | Val groups: {len(val_groups)}")
            print("Val group IDs:", sorted(map(str, val_groups)))

            # Important:
            # StandardScaler must be fitted only on the training set
            scaler_x = StandardScaler()
            X_train_scaled = scaler_x.fit_transform(X_train_raw).astype(np.float32)
            X_val_scaled = scaler_x.transform(X_val_raw).astype(np.float32)

            X_train_gru = to_gru_input(X_train_scaled)
            X_val_gru = to_gru_input(X_val_scaled)

            train_loader = make_loader(
                X_train_gru,
                y_train,
                batch_size=BATCH_SIZE,
                shuffle=True,
            )

            val_loader = make_loader(
                X_val_gru,
                y_val.reshape(-1, 1),
                batch_size=BATCH_SIZE,
                shuffle=False,
            )

            model = GRURegressor(
                input_dim=len(features),
                hidden_size=HIDDEN_SIZE,
                num_layers=NUM_LAYERS,
                dropout=DROPOUT,
            ).to(DEVICE)

            model, best_epoch, best_val_loss = train_one_fold(
                model=model,
                train_loader=train_loader,
                val_loader=val_loader,
                epochs=EPOCHS,
                lr=LEARNING_RATE,
                patience=PATIENCE,
            )

            y_pred = predict_model(model, X_val_gru, batch_size=BATCH_SIZE)

            r2 = float(r2_score(y_val, y_pred))
            mae = float(mean_absolute_error(y_val, y_pred))
            rmse = rmse_score(y_val, y_pred)

            print(
                f"Fold {fold} metrics | "
                f"R2={r2:.6f} | MAE={mae:.6f} | RMSE={rmse:.6f}"
            )

            rows.append(
                {
                    "ablation_order": ablation_order,
                    "ablation": ablation_name,
                    "fold": fold,
                    "n_features": len(features),
                    "features": ",".join(features),
                    "n_train": len(train_idx),
                    "n_val": len(val_idx),
                    "n_train_groups": len(train_groups),
                    "n_val_groups": len(val_groups),
                    "val_groups": ",".join(map(str, sorted(val_groups))),
                    "best_epoch": best_epoch,
                    "best_val_loss": best_val_loss,
                    "R2": r2,
                    "MAE": mae,
                    "RMSE": rmse,
                }
            )

    return pd.DataFrame(rows)


def summarize_results(by_fold: pd.DataFrame) -> pd.DataFrame:
    summary = (
        by_fold
        .groupby(["ablation_order", "ablation"], sort=True)
        .agg(
            n_folds=("fold", "count"),
            n_features=("n_features", "first"),
            features=("features", "first"),
            R2_mean=("R2", "mean"),
            R2_std=("R2", "std"),
            MAE_mean=("MAE", "mean"),
            MAE_std=("MAE", "std"),
            RMSE_mean=("RMSE", "mean"),
            RMSE_std=("RMSE", "std"),
            best_epoch_mean=("best_epoch", "mean"),
            best_epoch_std=("best_epoch", "std"),
        )
        .reset_index()
        .sort_values("ablation_order")
        .reset_index(drop=True)
    )

    full_row = summary[summary["ablation"] == "Full"].iloc[0]

    summary["Delta_R2"] = summary["R2_mean"] - full_row["R2_mean"]
    summary["Delta_MAE"] = summary["MAE_mean"] - full_row["MAE_mean"]
    summary["Delta_RMSE"] = summary["RMSE_mean"] - full_row["RMSE_mean"]

    # For easier interpretation:
    # R2 drop is positive when performance becomes worse.
    summary["R2_drop"] = full_row["R2_mean"] - summary["R2_mean"]
    summary["MAE_increase"] = summary["MAE_mean"] - full_row["MAE_mean"]
    summary["RMSE_increase"] = summary["RMSE_mean"] - full_row["RMSE_mean"]

    return summary


# ============================================================
# 7. Plot
# ============================================================

def plot_summary(summary: pd.DataFrame) -> None:
    labels = summary["ablation"].tolist()
    x = np.arange(len(labels))

    metrics = [
        ("R2_mean", "R2_std", "(a) $R^2$", "$R^2$"),
        ("MAE_mean", "MAE_std", "(b) MAE", "MAE (GPa)"),
        ("RMSE_mean", "RMSE_std", "(c) RMSE", "RMSE (GPa)"),
    ]

    fig, axes = plt.subplots(1, 3, figsize=(14.5, 4.8))

    for ax, (mean_col, std_col, title, ylabel) in zip(axes, metrics):
        means = summary[mean_col].to_numpy(dtype=float)
        stds = summary[std_col].fillna(0.0).to_numpy(dtype=float)

        ax.bar(
            x,
            means,
            yerr=stds,
            capsize=4,
            edgecolor="black",
            linewidth=0.8,
        )

        ax.set_title(title)
        ax.set_ylabel(ylabel)
        ax.set_xticks(x)
        ax.set_xticklabels(labels, rotation=35, ha="right")
        ax.grid(axis="y", linestyle="--", alpha=0.35)

    fig.tight_layout()
    fig.savefig(SUMMARY_PNG, dpi=600, bbox_inches="tight")
    fig.savefig(SUMMARY_PDF, bbox_inches="tight")
    plt.close(fig)


# ============================================================
# 8. Main
# ============================================================

def main():
    print("=" * 90)
    print("GRU feature-group ablation analysis")
    print("Device:", DEVICE)
    print("Dataset:", DATA_PATH)
    print("Output directory:", OUTPUT_DIR)
    print("=" * 90)

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    df = load_dataset()

    print("\nDataset loaded successfully.")
    print("Rows:", len(df))
    print("Unique groups:", df[COL_GROUP].nunique())
    print("Target column:", COL_TARGET)
    print("All features:", ", ".join(ALL_FEATURES))

    print("\nGroup sample counts:")
    print(df[COL_GROUP].value_counts().sort_index())

    by_fold = run_ablation(df)
    summary = summarize_results(by_fold)

    by_fold.to_csv(BY_FOLD_CSV, index=False, encoding="utf-8-sig")
    summary.to_csv(SUMMARY_CSV, index=False, encoding="utf-8-sig")

    plot_summary(summary)

    print("\nSaved files:")
    print(BY_FOLD_CSV)
    print(SUMMARY_CSV)
    print(SUMMARY_PNG)
    print(SUMMARY_PDF)

    print("\nAblation summary:")
    display_cols = [
        "ablation",
        "n_features",
        "R2_mean",
        "R2_std",
        "MAE_mean",
        "MAE_std",
        "RMSE_mean",
        "RMSE_std",
        "Delta_R2",
        "Delta_MAE",
        "Delta_RMSE",
        "R2_drop",
        "MAE_increase",
        "RMSE_increase",
    ]

    print(summary[display_cols].to_string(index=False))


if __name__ == "__main__":
    main()