# -*- coding: utf-8 -*-
"""
09_calc_virtual_candidate_metrics.py

功能：
    1. 读取 08_predict_virtual_candidates_gru.py 输出的虚拟候选结构预测曲线；
    2. 从每个虚拟候选结构的预测应力-应变曲线中提取循环性能指标；
    3. 计算 sigma_max、epsilon_res、DeltaW、R_sigma、R_W、Delta_epsilon_res；
    4. 使用真实 MD 主工况指标的 min-max 范围，对虚拟候选结构计算 local FSI；
    5. 按 FSI_mean、R_W、残余应变等指标对虚拟候选结构排序；
    6. 输出虚拟候选结构排名、Top 结构和候选优选 gd 区间；
    7. 输出 Origin 作图用的 origin_surface_data 表。

重要修改：
    residual strain 不再简单使用 abs(stress) 最小点。
    新逻辑：
        1. 如果卸载曲线存在 stress = 0 点，直接取该点；
        2. 如果卸载曲线穿过 0，用相邻两点线性插值；
        3. 如果没有穿过 0，但最低应力足够接近 0，即 min|stress| <= 0.30 GPa，
           则只用最近零应力点附近的局部窗口线性外推到 stress = 0；
        4. 如果外推结果离最近点太远，则退回 nearest-point fallback。

输入：
    E:\TiNi_4_code\virtual_predictions\virtual_gru_predictions.xlsx

参考归一化输入：
    E:\TiNi_4_code\gru_full_metrics_results_10features_h128_lr1e3_epoch300\gru_full_cyclic_descriptors.xlsx

输出：
    E:\TiNi_4_code\virtual_candidate_metrics\virtual_candidate_metrics.xlsx
"""

from pathlib import Path

import numpy as np
import pandas as pd


# =========================================================
# 1. 路径设置
# =========================================================

BASE_DIR = Path(r"E:\TiNi_4_code")

VIRTUAL_PRED_PATH = (
    BASE_DIR
    / "virtual_predictions"
    / "virtual_gru_predictions_234_source_paths.xlsx"
)

REAL_FULL_METRICS_PATH = (
    BASE_DIR
    / "gru_sequence_final_v3_packed_bestepoch_h256_lr1e3"
    / "sequence_cyclic_descriptors.xlsx"
)

OUTPUT_DIR = BASE_DIR / "virtual_candidate_metrics"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

OUTPUT_EXCEL = OUTPUT_DIR / "virtual_candidate_metrics_234_source_paths_validated.xlsx"


# =========================================================
# 2. 基本设置
# =========================================================

MAIN_T = 400
MAIN_EMAX = 10

TOP_N_LIST = [5, 10, 20]


# =========================================================
# 3. residual strain 计算参数
# =========================================================

# 如果卸载段最低应力小于这个值，认为可以尝试外推到 stress = 0
RES_EXTRAP_MAX_MIN_ABS_STRESS = 0.30  # GPa

# 局部拟合窗口：以最接近 0 应力的点为中心，前后各取几个点
RES_LOCAL_HALF_WINDOW = 4

# 外推结果最多允许偏离最近点多少 strain，单位是 %
# 比如最近点是 1.92%，外推结果不能离它超过 0.30%
RES_MAX_EXTRAP_DELTA_STRAIN = 0.30

# 局部线性拟合至少需要的点数
RES_FIT_MIN_POINTS = 5


# =========================================================
# 4. 列名设置
# =========================================================

COL_ID = "candidate_id"

COL_DMIN = "d_min (nm)"
COL_DMAX = "d_max (nm)"
COL_DAVG = "Davg"
COL_GD = "gd"
COL_GB = "GB_frac0"

COL_T = "T (K)"
COL_EMAX = "Max Strain(%)"

COL_CYCLE = "cycle_n"
COL_STATUS = "Load_Status"
COL_STRAIN = "Current_Strain"

COL_PRED = "Current_Stress_pred"

GROUP_KEYS_CYCLE = [COL_ID, COL_T, COL_EMAX, COL_CYCLE]
GROUP_KEYS_CANDIDATE = [COL_ID, COL_T, COL_EMAX]

META_COLS = [
    "candidate_type",
    "source_ID_A",
    "source_ID_B",
    "alpha_from_A_to_B",
    COL_DMIN,
    COL_DMAX,
    COL_DAVG,
    COL_GD,
    COL_GB,
    "nearest_real_ID",
    "nearest_real_distance_scaled",
    "in_main_gd_range",
]


# =========================================================
# 5. 工具函数
# =========================================================

def integrate_trapz(y, x):
    if hasattr(np, "trapezoid"):
        return np.trapezoid(y, x)
    return np.trapz(y, x)


def minmax_norm_by_ref(s, ref, clip=False):
    """
    用 ref 的 min/max 对 s 归一化。
    clip=True 时，将归一化结果限制在 [0, 1]。
    """
    s = s.astype(float)
    ref = ref.astype(float)

    ref_min = ref.min(skipna=True)
    ref_max = ref.max(skipna=True)

    if pd.isna(ref_min) or pd.isna(ref_max):
        return pd.Series(np.nan, index=s.index)

    if ref_max == ref_min:
        return pd.Series(0.5, index=s.index)

    out = (s - ref_min) / (ref_max - ref_min)

    if clip:
        out = out.clip(0.0, 1.0)

    return out


def calc_residual_strain_by_interpolation(unload, stress_col):
    """
    计算 residual strain。

    逻辑：
        1. 若卸载曲线存在 stress = 0 点，直接取该点；
        2. 若卸载曲线穿过 0，用相邻两点线性插值；
        3. 若没有穿过 0，但最低应力足够接近 0，
           用最近零应力点附近的局部窗口线性外推；
        4. 若外推不可靠，则退回到 abs(stress) 最小点。

    返回：
        epsilon_res
        stress_at_res
        method
        min_abs_stress
    """
    if len(unload) == 0:
        return np.nan, np.nan, "no_unloading", np.nan

    unload = unload.sort_values("template_row_order").copy()

    strain = unload[COL_STRAIN].to_numpy(dtype=float)
    stress = unload[stress_col].to_numpy(dtype=float)

    valid_mask = (~np.isnan(strain)) & (~np.isnan(stress))
    strain = strain[valid_mask]
    stress = stress[valid_mask]

    if len(stress) == 0:
        return np.nan, np.nan, "no_valid_points", np.nan

    abs_stress = np.abs(stress)
    min_abs_stress = float(np.nanmin(abs_stress))

    # -----------------------------------------------------
    # 1. 如果刚好有 stress = 0 的点
    # -----------------------------------------------------
    zero_mask = np.isclose(stress, 0.0, atol=1e-10)

    if zero_mask.any():
        idx = np.where(zero_mask)[0][0]
        return float(strain[idx]), float(stress[idx]), "exact_zero", min_abs_stress

    # -----------------------------------------------------
    # 2. 如果相邻点穿过 0，用线性插值
    # -----------------------------------------------------
    sign_change_indices = []

    for i in range(len(stress) - 1):
        s1 = stress[i]
        s2 = stress[i + 1]

        if np.isnan(s1) or np.isnan(s2):
            continue

        if s1 * s2 < 0:
            sign_change_indices.append(i)

    if len(sign_change_indices) > 0:
        best_i = min(
            sign_change_indices,
            key=lambda i: abs(stress[i]) + abs(stress[i + 1])
        )

        s1 = stress[best_i]
        s2 = stress[best_i + 1]
        e1 = strain[best_i]
        e2 = strain[best_i + 1]

        if s2 == s1:
            epsilon_res = e1
        else:
            epsilon_res = e1 + (0.0 - s1) * (e2 - e1) / (s2 - s1)

        return float(epsilon_res), 0.0, "zero_crossing_interpolation", min_abs_stress

    # -----------------------------------------------------
    # 3. 没穿过 0：用最近零应力点附近的局部窗口外推
    # -----------------------------------------------------
    idx0 = int(np.nanargmin(abs_stress))
    nearest_strain = float(strain[idx0])
    nearest_stress = float(stress[idx0])

    if min_abs_stress <= RES_EXTRAP_MAX_MIN_ABS_STRESS:
        i_start = max(0, idx0 - RES_LOCAL_HALF_WINDOW)
        i_end = min(len(stress), idx0 + RES_LOCAL_HALF_WINDOW + 1)

        fit_strain = strain[i_start:i_end]
        fit_stress = stress[i_start:i_end]

        valid_fit = (~np.isnan(fit_strain)) & (~np.isnan(fit_stress))
        fit_strain = fit_strain[valid_fit]
        fit_stress = fit_stress[valid_fit]

        if len(fit_stress) >= RES_FIT_MIN_POINTS and len(np.unique(fit_strain)) >= 2:
            try:
                # 拟合 stress = a * strain + b
                a, b = np.polyfit(fit_strain, fit_stress, 1)

                if abs(a) > 1e-12:
                    epsilon_res = -b / a

                    # 只接受局部小幅外推，防止外推出离谱残余应变
                    if abs(epsilon_res - nearest_strain) <= RES_MAX_EXTRAP_DELTA_STRAIN:
                        strain_min = float(np.nanmin(strain))
                        strain_max = float(np.nanmax(strain))

                        if strain_min <= epsilon_res <= strain_max:
                            return (
                                float(epsilon_res),
                                0.0,
                                "local_linear_extrapolation",
                                min_abs_stress
                            )

            except Exception:
                pass

    # -----------------------------------------------------
    # 4. fallback：最近点
    # -----------------------------------------------------
    return (
        nearest_strain,
        nearest_stress,
        "nearest_point_fallback",
        min_abs_stress
    )


def calc_cycle_descriptors(group, stress_col):
    """
    对一个 candidate + T + Max Strain + cycle_n 的完整加载-卸载路径计算：
        sigma_max
        epsilon_res
        DeltaW

    residual strain 采用：
        exact zero
        zero crossing interpolation
        local linear extrapolation
        nearest-point fallback
    """
    group = group.sort_values("template_row_order").copy()

    stress = group[stress_col].to_numpy(dtype=float)
    strain_percent = group[COL_STRAIN].to_numpy(dtype=float)

    sigma_max = np.nanmax(stress)

    unload = group[group[COL_STATUS] == -1].copy()

    if len(unload) > 0:
        epsilon_res, stress_at_res, epsilon_res_method, min_abs_stress = (
            calc_residual_strain_by_interpolation(unload, stress_col)
        )
    else:
        epsilon_res = np.nan
        stress_at_res = np.nan
        epsilon_res_method = "no_unloading"
        min_abs_stress = np.nan

    if len(group) >= 2:
        # Keep both conventions explicit. With stress in GPa and strain in %:
        # 1 GPa*percent = 10 MJ/m^3.
        deltaW_GPa_percent = abs(integrate_trapz(stress, strain_percent))
        deltaW_MJ_m3 = deltaW_GPa_percent * 10.0
    else:
        deltaW_GPa_percent = np.nan
        deltaW_MJ_m3 = np.nan

    return pd.Series({
        "sigma_max_GPa_pred": sigma_max,
        "epsilon_res_percent_pred": epsilon_res,
        "stress_at_epsilon_res_GPa_pred": stress_at_res,
        "epsilon_res_method_pred": epsilon_res_method,
        "min_abs_stress_unload_GPa_pred": min_abs_stress,
        "DeltaW_GPa_percent_pred": deltaW_GPa_percent,
        "DeltaW_MJ_m3_pred": deltaW_MJ_m3,
        "n_points": len(group),
    })


def build_virtual_descriptors(df):
    """
    从虚拟候选结构的点级预测应力曲线中构建：
        1. cycle-level descriptors
        2. candidate-level descriptors
    """
    cycle_desc = (
        df.groupby(GROUP_KEYS_CYCLE, sort=False)
        .apply(lambda g: calc_cycle_descriptors(g, COL_PRED))
        .reset_index()
    )

    available_meta_cols = [c for c in META_COLS if c in df.columns]

    meta = (
        df.groupby(GROUP_KEYS_CANDIDATE, sort=False)[available_meta_cols]
        .first()
        .reset_index()
    )

    cycle_desc = cycle_desc.merge(
        meta,
        on=GROUP_KEYS_CANDIDATE,
        how="left"
    )

    cycle1 = cycle_desc[cycle_desc[COL_CYCLE] == 1].set_index(GROUP_KEYS_CANDIDATE)
    cycle8 = cycle_desc[cycle_desc[COL_CYCLE] == 8].set_index(GROUP_KEYS_CANDIDATE)

    cand_desc = meta.set_index(GROUP_KEYS_CANDIDATE).copy()

    cand_desc["sigma_max_1_GPa_pred"] = cycle1["sigma_max_GPa_pred"]
    cand_desc["sigma_max_8_GPa_pred"] = cycle8["sigma_max_GPa_pred"]

    cand_desc["epsilon_res_1_percent_pred"] = cycle1["epsilon_res_percent_pred"]
    cand_desc["epsilon_res_8_percent_pred"] = cycle8["epsilon_res_percent_pred"]

    cand_desc["stress_at_epsilon_res_1_GPa_pred"] = cycle1["stress_at_epsilon_res_GPa_pred"]
    cand_desc["stress_at_epsilon_res_8_GPa_pred"] = cycle8["stress_at_epsilon_res_GPa_pred"]

    cand_desc["epsilon_res_1_method_pred"] = cycle1["epsilon_res_method_pred"]
    cand_desc["epsilon_res_8_method_pred"] = cycle8["epsilon_res_method_pred"]

    cand_desc["min_abs_stress_unload_1_GPa_pred"] = cycle1["min_abs_stress_unload_GPa_pred"]
    cand_desc["min_abs_stress_unload_8_GPa_pred"] = cycle8["min_abs_stress_unload_GPa_pred"]

    cand_desc["DeltaW_1_MJ_m3_pred"] = cycle1["DeltaW_MJ_m3_pred"]
    cand_desc["DeltaW_8_MJ_m3_pred"] = cycle8["DeltaW_MJ_m3_pred"]
    cand_desc["DeltaW_1_GPa_percent_pred"] = cycle1["DeltaW_GPa_percent_pred"]
    cand_desc["DeltaW_8_GPa_percent_pred"] = cycle8["DeltaW_GPa_percent_pred"]

    cand_desc["R_sigma_pred"] = (
        cand_desc["sigma_max_8_GPa_pred"] /
        cand_desc["sigma_max_1_GPa_pred"]
    )

    cand_desc["R_W_pred"] = (
        cand_desc["DeltaW_8_GPa_percent_pred"] /
        cand_desc["DeltaW_1_GPa_percent_pred"]
    )
    cand_desc["W_degradation_rate_pred"] = 1.0 - cand_desc["R_W_pred"]
    cand_desc["W_degradation_percent_pred"] = 100.0 * cand_desc["W_degradation_rate_pred"]

    cand_desc["Delta_epsilon_res_percent_pred"] = (
        cand_desc["epsilon_res_8_percent_pred"] -
        cand_desc["epsilon_res_1_percent_pred"]
    )

    cand_desc = cand_desc.reset_index()

    return cycle_desc, cand_desc


def add_virtual_fsi_columns(virtual_df, real_ref_df):
    """
    用真实 MD 主工况的 true 指标作为 min-max 归一化参考，
    计算虚拟候选结构的 FSI。
    """
    out = virtual_df.copy()

    # ---------- 不截断版本 ----------
    out["R_sigma_norm_pred_local"] = minmax_norm_by_ref(
        out["R_sigma_pred"],
        real_ref_df["R_sigma_true"],
        clip=False
    )

    out["R_W_norm_pred_local"] = minmax_norm_by_ref(
        out["R_W_pred"],
        real_ref_df["R_W_true"],
        clip=False
    )

    out["epsilon_res_8_norm_pred_local"] = minmax_norm_by_ref(
        out["epsilon_res_8_percent_pred"],
        real_ref_df["epsilon_res_8_percent_true"],
        clip=False
    )

    out["Delta_epsilon_res_norm_pred_local"] = minmax_norm_by_ref(
        out["Delta_epsilon_res_percent_pred"],
        real_ref_df["Delta_epsilon_res_percent_true"],
        clip=False
    )

    out["FSI_final_state_pred_local"] = (
        out["R_sigma_norm_pred_local"]
        + out["R_W_norm_pred_local"]
        - out["epsilon_res_8_norm_pred_local"]
    )

    out["FSI_degradation_pred_local"] = (
        out["R_sigma_norm_pred_local"]
        + out["R_W_norm_pred_local"]
        - out["Delta_epsilon_res_norm_pred_local"]
    )

    out["FSI_mean_pred_local"] = (
        out["FSI_final_state_pred_local"]
        + out["FSI_degradation_pred_local"]
    ) / 2.0

    # ---------- 截断版本 ----------
    out["R_sigma_norm_pred_local_clipped"] = minmax_norm_by_ref(
        out["R_sigma_pred"],
        real_ref_df["R_sigma_true"],
        clip=True
    )

    out["R_W_norm_pred_local_clipped"] = minmax_norm_by_ref(
        out["R_W_pred"],
        real_ref_df["R_W_true"],
        clip=True
    )

    out["epsilon_res_8_norm_pred_local_clipped"] = minmax_norm_by_ref(
        out["epsilon_res_8_percent_pred"],
        real_ref_df["epsilon_res_8_percent_true"],
        clip=True
    )

    out["Delta_epsilon_res_norm_pred_local_clipped"] = minmax_norm_by_ref(
        out["Delta_epsilon_res_percent_pred"],
        real_ref_df["Delta_epsilon_res_percent_true"],
        clip=True
    )

    out["FSI_final_state_pred_local_clipped"] = (
        out["R_sigma_norm_pred_local_clipped"]
        + out["R_W_norm_pred_local_clipped"]
        - out["epsilon_res_8_norm_pred_local_clipped"]
    )

    out["FSI_degradation_pred_local_clipped"] = (
        out["R_sigma_norm_pred_local_clipped"]
        + out["R_W_norm_pred_local_clipped"]
        - out["Delta_epsilon_res_norm_pred_local_clipped"]
    )

    out["FSI_mean_pred_local_clipped"] = (
        out["FSI_final_state_pred_local_clipped"]
        + out["FSI_degradation_pred_local_clipped"]
    ) / 2.0

    return out


def add_ranks(df):
    """
    添加排序列。
    主排序：
        FSI_mean_pred_local_clipped 越大越好

    辅助排序：
        R_W_pred 越大越好
        epsilon_res_8_percent_pred 越小越好
        Delta_epsilon_res_percent_pred 越小越好
    """
    out = df.copy()

    out["rank_FSI_mean_clipped"] = out["FSI_mean_pred_local_clipped"].rank(
        ascending=False,
        method="min"
    )

    out["rank_R_W"] = out["R_W_pred"].rank(
        ascending=False,
        method="min"
    )

    out["rank_epsilon_res_8"] = out["epsilon_res_8_percent_pred"].rank(
        ascending=True,
        method="min"
    )

    out["rank_Delta_epsilon_res"] = out["Delta_epsilon_res_percent_pred"].rank(
        ascending=True,
        method="min"
    )

    out["robust_rank_score"] = (
        out["rank_FSI_mean_clipped"]
        + out["rank_R_W"]
        + out["rank_epsilon_res_8"]
        + out["rank_Delta_epsilon_res"]
    ) / 4.0

    out["rank_robust_score"] = out["robust_rank_score"].rank(
        ascending=True,
        method="min"
    )

    return out


def summarize_top_interval(rank_df, rank_col, top_n):
    """
    汇总 Top N 候选的 gd 区间。
    """
    top = rank_df.sort_values(rank_col, ascending=True).head(top_n).copy()

    return {
        "ranking_basis": rank_col,
        "top_n": top_n,
        "gd_min": top[COL_GD].min(),
        "gd_max": top[COL_GD].max(),
        "gd_mean": top[COL_GD].mean(),
        "gd_median": top[COL_GD].median(),
        "Davg_min": top[COL_DAVG].min(),
        "Davg_max": top[COL_DAVG].max(),
        "GB_frac0_min": top[COL_GB].min(),
        "GB_frac0_max": top[COL_GB].max(),
        "candidate_ids": ", ".join(top[COL_ID].astype(str).tolist()),
    }


def build_origin_surface_data(virtual_metrics):
    """
    输出给 Origin 画 3D response surface 用的简化数据表。

    Origin 推荐：
        X = gd
        Y = Davg
        Z = sigma_max_1_GPa_pred / epsilon_res_8_percent_pred / DeltaW_8_MJ_m3_pred / R_W_pred / FSI_mean_pred_local_clipped
    """
    cols = [
        COL_ID,
        COL_GD,
        COL_DAVG,
        COL_DMIN,
        COL_DMAX,
        COL_GB,

        "sigma_max_1_GPa_pred",
        "sigma_max_8_GPa_pred",

        "epsilon_res_1_percent_pred",
        "epsilon_res_8_percent_pred",
        "Delta_epsilon_res_percent_pred",

        "stress_at_epsilon_res_1_GPa_pred",
        "stress_at_epsilon_res_8_GPa_pred",

        "epsilon_res_1_method_pred",
        "epsilon_res_8_method_pred",

        "min_abs_stress_unload_1_GPa_pred",
        "min_abs_stress_unload_8_GPa_pred",

        "DeltaW_1_GPa_percent_pred",
        "DeltaW_8_GPa_percent_pred",
        "DeltaW_1_MJ_m3_pred",
        "DeltaW_8_MJ_m3_pred",

        "R_sigma_pred",
        "R_W_pred",
        "W_degradation_rate_pred",
        "W_degradation_percent_pred",

        "FSI_final_state_pred_local_clipped",
        "FSI_degradation_pred_local_clipped",
        "FSI_mean_pred_local_clipped",

        "robust_rank_score",
        "rank_FSI_mean_clipped",
        "rank_robust_score",

        "nearest_real_ID",
        "nearest_real_distance_scaled",
        "in_main_gd_range",
    ]

    cols = [c for c in cols if c in virtual_metrics.columns]

    out = virtual_metrics[cols].copy()
    out = out.sort_values([COL_GD, COL_DAVG]).reset_index(drop=True)

    return out


# =========================================================
# 6. 检查输入文件
# =========================================================

print("=" * 80)
print("09_calc_virtual_candidate_metrics.py")
print("=" * 80)

if not VIRTUAL_PRED_PATH.exists():
    raise FileNotFoundError(f"找不到虚拟候选预测文件：{VIRTUAL_PRED_PATH}")

if not REAL_FULL_METRICS_PATH.exists():
    raise FileNotFoundError(f"找不到真实 MD/full GRU 指标文件：{REAL_FULL_METRICS_PATH}")


# =========================================================
# 7. 读取虚拟候选预测结果
# =========================================================

print("\nReading virtual prediction file:")
print(VIRTUAL_PRED_PATH)

virtual_df = pd.read_excel(VIRTUAL_PRED_PATH, sheet_name="virtual_predictions")

required_cols = [
    COL_ID,
    COL_DMIN,
    COL_DMAX,
    COL_DAVG,
    COL_GD,
    COL_GB,
    COL_T,
    COL_EMAX,
    COL_CYCLE,
    COL_STATUS,
    COL_STRAIN,
    COL_PRED,
    "template_row_order",
]

missing = [c for c in required_cols if c not in virtual_df.columns]
if missing:
    raise ValueError(f"virtual_predictions 缺少这些列：{missing}")

for c in [
    COL_DMIN,
    COL_DMAX,
    COL_DAVG,
    COL_GD,
    COL_GB,
    COL_T,
    COL_EMAX,
    COL_CYCLE,
    COL_STATUS,
    COL_STRAIN,
    COL_PRED,
    "template_row_order",
]:
    virtual_df[c] = pd.to_numeric(virtual_df[c], errors="coerce")

virtual_df = virtual_df.dropna(subset=required_cols).copy()

print("Virtual prediction rows:", len(virtual_df))
print("Virtual candidates:", virtual_df[COL_ID].nunique())
print("gd range:", virtual_df[COL_GD].min(), "to", virtual_df[COL_GD].max())
print("Davg range:", virtual_df[COL_DAVG].min(), "to", virtual_df[COL_DAVG].max())


# =========================================================
# 8. 读取真实 MD 主工况指标，作为 FSI 归一化参考
# =========================================================

print("\nReading real MD reference metrics:")
print(REAL_FULL_METRICS_PATH)

real_main = pd.read_excel(
    REAL_FULL_METRICS_PATH,
    sheet_name="main_400K_10pct"
)

required_real_cols = [
    "R_sigma_true",
    "R_W_true",
    "epsilon_res_8_percent_true",
    "Delta_epsilon_res_percent_true",
    "FSI_mean_true_local",
]

missing_real = [c for c in required_real_cols if c not in real_main.columns]
if missing_real:
    raise ValueError(f"real main metrics 缺少这些列：{missing_real}")

for c in required_real_cols:
    real_main[c] = pd.to_numeric(real_main[c], errors="coerce")

real_main = real_main.dropna(subset=required_real_cols).copy()

print("Real main condition reference rows:", len(real_main))


# =========================================================
# 9. 提取虚拟候选结构循环指标
# =========================================================

print("\nExtracting cyclic descriptors from virtual predictions...")

cycle_virtual, virtual_metrics = build_virtual_descriptors(virtual_df)

for cycle_label, method_col in [
    (1, "epsilon_res_1_method_pred"),
    (8, "epsilon_res_8_method_pred"),
]:
    fallback_fraction = virtual_metrics[method_col].eq("nearest_point_fallback").mean()
    if fallback_fraction > 0.5:
        print(
            f"WARNING: cycle {cycle_label} residual strain uses nearest-point "
            f"fallback for {fallback_fraction:.1%} of candidates. "
            "Energy retention/degradation is unaffected, but residual-strain "
            "and composite FSI terms should be interpreted cautiously."
        )

virtual_metrics = add_virtual_fsi_columns(
    virtual_df=virtual_metrics,
    real_ref_df=real_main,
)

# Compare the reporting-unit first-cycle energy against the real 400 K / 10%
# range. Older descriptor files contain only MJ/m^3, so convert back explicitly.
if "DeltaW_1_GPa_percent_true" in real_main.columns:
    real_deltaW1 = pd.to_numeric(real_main["DeltaW_1_GPa_percent_true"], errors="coerce")
elif "DeltaW_1_MJ_m3_true" in real_main.columns:
    real_deltaW1 = pd.to_numeric(real_main["DeltaW_1_MJ_m3_true"], errors="coerce") / 10.0
else:
    real_deltaW1 = pd.Series(dtype=float)

if real_deltaW1.notna().any():
    real_deltaW1_min = float(real_deltaW1.min())
    real_deltaW1_max = float(real_deltaW1.max())
    virtual_metrics["DeltaW_1_real_min_GPa_percent"] = real_deltaW1_min
    virtual_metrics["DeltaW_1_real_max_GPa_percent"] = real_deltaW1_max
    virtual_metrics["DeltaW_1_to_real_max_ratio"] = (
        virtual_metrics["DeltaW_1_GPa_percent_pred"] / real_deltaW1_max
    )
    virtual_metrics["DeltaW_1_outside_real_range"] = ~virtual_metrics[
        "DeltaW_1_GPa_percent_pred"
    ].between(real_deltaW1_min, real_deltaW1_max)

    n_energy_outside = int(virtual_metrics["DeltaW_1_outside_real_range"].sum())
    print(
        "First-cycle real DeltaW range (GPa*percent): "
        f"{real_deltaW1_min:.4f} to {real_deltaW1_max:.4f}"
    )
    print(
        "First-cycle virtual DeltaW range (GPa*percent): "
        f"{virtual_metrics['DeltaW_1_GPa_percent_pred'].min():.4f} to "
        f"{virtual_metrics['DeltaW_1_GPa_percent_pred'].max():.4f}"
    )
    print(f"Candidates outside the real DeltaW range: {n_energy_outside}")

virtual_metrics = add_ranks(virtual_metrics)

origin_surface_data = build_origin_surface_data(virtual_metrics)

# 主排序：FSI clipped，从高到低
rank_by_fsi = virtual_metrics.sort_values(
    "rank_FSI_mean_clipped",
    ascending=True
).reset_index(drop=True)

# 稳健排序：FSI + R_W + 残余应变 + 残余应变增长
rank_by_robust = virtual_metrics.sort_values(
    "rank_robust_score",
    ascending=True
).reset_index(drop=True)


# =========================================================
# 10. 汇总 Top N gd 区间
# =========================================================

summary_rows = []

for n in TOP_N_LIST:
    summary_rows.append(
        summarize_top_interval(
            rank_df=rank_by_fsi,
            rank_col="rank_FSI_mean_clipped",
            top_n=n,
        )
    )

for n in TOP_N_LIST:
    summary_rows.append(
        summarize_top_interval(
            rank_df=rank_by_robust,
            rank_col="rank_robust_score",
            top_n=n,
        )
    )

top_interval_summary = pd.DataFrame(summary_rows)


# =========================================================
# 11. 保存 Excel
# =========================================================

print("\nSaving Excel output...")

with pd.ExcelWriter(OUTPUT_EXCEL, engine="openpyxl") as writer:
    virtual_df.to_excel(writer, sheet_name="virtual_point_predictions", index=False)
    cycle_virtual.to_excel(writer, sheet_name="virtual_cycle_level", index=False)
    virtual_metrics.to_excel(writer, sheet_name="virtual_candidate_metrics", index=False)

    origin_surface_data.to_excel(writer, sheet_name="origin_surface_data", index=False)

    rank_by_fsi.to_excel(writer, sheet_name="rank_by_FSI_clipped", index=False)
    rank_by_robust.to_excel(writer, sheet_name="rank_by_robust_score", index=False)

    rank_by_fsi.head(20).to_excel(writer, sheet_name="top20_by_FSI_clipped", index=False)
    rank_by_robust.head(20).to_excel(writer, sheet_name="top20_by_robust_score", index=False)

    top_interval_summary.to_excel(writer, sheet_name="top_gd_interval_summary", index=False)
    real_main.to_excel(writer, sheet_name="real_main_reference", index=False)


# =========================================================
# 12. 控制台输出
# =========================================================

show_cols = [
    COL_ID,
    COL_GD,
    COL_DAVG,
    COL_GB,
    "sigma_max_1_GPa_pred",
    "sigma_max_8_GPa_pred",
    "epsilon_res_1_percent_pred",
    "epsilon_res_8_percent_pred",
    "Delta_epsilon_res_percent_pred",
    "epsilon_res_1_method_pred",
    "epsilon_res_8_method_pred",
    "min_abs_stress_unload_1_GPa_pred",
    "min_abs_stress_unload_8_GPa_pred",
    "DeltaW_8_GPa_percent_pred",
    "DeltaW_8_MJ_m3_pred",
    "R_W_pred",
    "W_degradation_percent_pred",
    "FSI_mean_pred_local_clipped",
    "robust_rank_score",
    "nearest_real_ID",
    "nearest_real_distance_scaled",
]

show_cols = [c for c in show_cols if c in rank_by_fsi.columns]

print("\nTop 10 virtual candidates by FSI_mean_pred_local_clipped:")
print(rank_by_fsi[show_cols].head(10).to_string(index=False))

print("\nTop 10 virtual candidates by robust rank score:")
print(rank_by_robust[show_cols].head(10).to_string(index=False))

print("\nTop gd interval summary:")
print(top_interval_summary.to_string(index=False))

print("\nSaved Excel file:")
print(OUTPUT_EXCEL)

print("\nUse this sheet in Origin:")
print("origin_surface_data")

print("\nRecommended Origin 3D response surface settings:")
print("X = gd")
print("Y = Davg")
print("Z options:")
print("  1) sigma_max_1_GPa_pred")
print("  2) epsilon_res_8_percent_pred")
print("  3) DeltaW_8_GPa_percent_pred  (user/reporting convention)")
print("  4) DeltaW_8_MJ_m3_pred        (physical SI-derived unit)")
print("  5) R_W_pred                    (retention ratio)")
print("  6) W_degradation_percent_pred  (100 * (1 - R_W))")
print("  7) FSI_mean_pred_local_clipped")

print("\nCheck residual strain columns:")
print("  epsilon_res_1_percent_pred")
print("  epsilon_res_8_percent_pred")
print("  epsilon_res_1_method_pred")
print("  epsilon_res_8_method_pred")
print("  min_abs_stress_unload_1_GPa_pred")
print("  min_abs_stress_unload_8_GPa_pred")

print("\nIf method is mainly 'local_linear_extrapolation',")
print("residual strain was calculated by local extrapolation near the nearest-zero stress point.")

print("If method is mainly 'nearest_point_fallback',")
print("the extrapolated zero-stress strain was too far from the nearest point or not reliable.")

print("\nAll done.")
