# -*- coding: utf-8 -*-
"""
07_generate_virtual_candidates.py

功能：
    在已有 18 个真实结构设计空间附近生成虚拟候选梯度结构。

说明：
    这一步只生成候选结构参数表，不进行 GRU 预测。
    后续 08_predict_virtual_candidates_gru.py 会读取该候选表，
    构造完整循环路径，并用 final GRU 预测 Current_Stress。

输入：
    E:\TiNi_4_code\Dataset.xlsx

可选输入：
    E:\TiNi_4_code\gru_full_metrics_results_10features_h128_lr1e3_epoch300\gru_full_cyclic_descriptors.xlsx
    如果存在，则读取主工况真实 FSI 排名前 5 的结构，并额外生成 Top 结构附近插值候选。

输出：
    E:\TiNi_4_code\virtual_candidates\
        virtual_design_candidates.xlsx
        figures\
"""

from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.preprocessing import StandardScaler
from sklearn.metrics import pairwise_distances


# =========================================================
# 1. 路径设置
# =========================================================

BASE_DIR = Path(r"E:\TiNi_4_code")

DATA_PATH = BASE_DIR / "Dataset.xlsx"
SHEET_NAME = "全部"

# 可选：用于读取真实 MD 主工况 Top 结构
FULL_METRICS_PATH = (
    BASE_DIR
    / "gru_full_metrics_results_10features_h128_lr1e3_epoch300"
    / "gru_full_cyclic_descriptors.xlsx"
)

OUTPUT_DIR = BASE_DIR / "virtual_candidates"
FIG_DIR = OUTPUT_DIR / "figures"

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
FIG_DIR.mkdir(parents=True, exist_ok=True)

OUTPUT_EXCEL = OUTPUT_DIR / "virtual_design_candidates.xlsx"


# =========================================================
# 2. 生成参数设置
# =========================================================

MAIN_T = 400
MAIN_EMAX = 10

# 第一版重点关注已有真实结果显示较优的中低到中等 gd 区间
GD_MAIN_MIN = 0.4
GD_MAIN_MAX = 1.8

# 相邻真实结构之间插值点数量
N_PER_ADJACENT_SEGMENT = 12

# Top 结构两两插值点的 alpha
TOP_PAIR_ALPHAS = [0.25, 0.50, 0.75]

# 去重时的小数精度
ROUND_DIGITS = 5


# =========================================================
# 3. 列名
# =========================================================

COL_ID = "ID"
COL_DMIN = "d_min (nm)"
COL_DMAX = "d_max (nm)"
COL_DAVG = "Davg"
COL_GD = "gd"
COL_GB = "GB_frac0"
COL_EMAX = "Max Strain(%)"
COL_T = "T (K)"

STRUCTURE_COLS = [
    COL_DMIN,
    COL_DMAX,
    COL_DAVG,
    COL_GD,
    COL_GB,
]


# =========================================================
# 4. 工具函数
# =========================================================

def calc_gd_from_sizes(d_min, d_max):
    return d_max / d_min - 1.0


def interpolate_row(row_a, row_b, alpha):
    """
    在两个真实结构之间插值。
    注意：
        d_min, d_max, Davg, GB_frac0 线性插值；
        gd 由 d_max / d_min - 1 重新计算，保证几何一致性。
    """
    dmin = (1 - alpha) * row_a[COL_DMIN] + alpha * row_b[COL_DMIN]
    dmax = (1 - alpha) * row_a[COL_DMAX] + alpha * row_b[COL_DMAX]
    davg = (1 - alpha) * row_a[COL_DAVG] + alpha * row_b[COL_DAVG]
    gb = (1 - alpha) * row_a[COL_GB] + alpha * row_b[COL_GB]

    gd = calc_gd_from_sizes(dmin, dmax)

    return {
        COL_DMIN: dmin,
        COL_DMAX: dmax,
        COL_DAVG: davg,
        COL_GD: gd,
        COL_GB: gb,
    }


def add_nearest_real_distance(candidates, real_structures):
    """
    计算每个虚拟候选点到最近真实结构的标准化距离。
    距离越小，说明越接近已有设计空间。
    """
    feature_cols = STRUCTURE_COLS

    scaler = StandardScaler()
    real_x = real_structures[feature_cols].to_numpy(dtype=float)
    cand_x = candidates[feature_cols].to_numpy(dtype=float)

    real_scaled = scaler.fit_transform(real_x)
    cand_scaled = scaler.transform(cand_x)

    dist = pairwise_distances(cand_scaled, real_scaled, metric="euclidean")

    nearest_idx = dist.argmin(axis=1)
    nearest_dist = dist.min(axis=1)

    candidates = candidates.copy()
    candidates["nearest_real_ID"] = real_structures.iloc[nearest_idx][COL_ID].values
    candidates["nearest_real_distance_scaled"] = nearest_dist

    return candidates


def add_range_flags(candidates, real_structures):
    """
    标记候选点是否落在已有真实结构的逐特征范围内。
    """
    candidates = candidates.copy()

    for col in STRUCTURE_COLS:
        cmin = real_structures[col].min()
        cmax = real_structures[col].max()
        candidates[f"in_range_{col}"] = (
            (candidates[col] >= cmin) &
            (candidates[col] <= cmax)
        )

    flag_cols = [f"in_range_{col}" for col in STRUCTURE_COLS]
    candidates["in_real_structure_feature_range"] = candidates[flag_cols].all(axis=1)

    candidates["in_main_gd_range"] = (
        (candidates[COL_GD] >= GD_MAIN_MIN) &
        (candidates[COL_GD] <= GD_MAIN_MAX)
    )

    return candidates


def clean_duplicate_candidates(candidates):
    """
    根据结构参数去重。
    """
    candidates = candidates.copy()

    for col in STRUCTURE_COLS:
        candidates[f"{col}_round"] = candidates[col].round(ROUND_DIGITS)

    round_cols = [f"{col}_round" for col in STRUCTURE_COLS]

    candidates = candidates.drop_duplicates(subset=round_cols).copy()

    candidates = candidates.drop(columns=round_cols)

    return candidates


# =========================================================
# 5. 读取 Dataset，提取 18 个真实结构参数
# =========================================================

print("=" * 80)
print("Reading Dataset.xlsx")
print(DATA_PATH)
print("=" * 80)

if not DATA_PATH.exists():
    raise FileNotFoundError(f"找不到 Dataset.xlsx: {DATA_PATH}")

df = pd.read_excel(DATA_PATH, sheet_name=SHEET_NAME)

required_cols = [
    COL_ID,
    COL_DMIN,
    COL_DMAX,
    COL_DAVG,
    COL_GD,
    COL_GB,
    COL_T,
    COL_EMAX,
]

missing = [c for c in required_cols if c not in df.columns]
if missing:
    raise ValueError(f"Dataset.xlsx 缺少这些列: {missing}")

for c in [COL_DMIN, COL_DMAX, COL_DAVG, COL_GD, COL_GB, COL_T, COL_EMAX]:
    df[c] = pd.to_numeric(df[c], errors="coerce")

df = df.dropna(subset=required_cols).copy()

real_structures = (
    df.groupby(COL_ID, sort=False)[[COL_DMIN, COL_DMAX, COL_DAVG, COL_GD, COL_GB]]
    .first()
    .reset_index()
)

real_structures["gd_calc_from_dmax_dmin"] = calc_gd_from_sizes(
    real_structures[COL_DMIN],
    real_structures[COL_DMAX],
)

real_structures["gd_error_dataset_minus_calc"] = (
    real_structures[COL_GD] - real_structures["gd_calc_from_dmax_dmin"]
)

# 后续虚拟候选统一使用几何计算得到的 gd；
# 真实结构表中仍保留 Dataset 原始 gd 和 gd_calc 方便检查。
real_structures = real_structures.sort_values(COL_GD).reset_index(drop=True)

print("Real structure count:", len(real_structures))
print("\nReal structure library:")
print(
    real_structures[
        [COL_ID, COL_DMIN, COL_DMAX, COL_DAVG, COL_GD, COL_GB, "gd_calc_from_dmax_dmin"]
    ].to_string(index=False)
)

print("\nGD dataset-vs-calculated max abs error:")
print(real_structures["gd_error_dataset_minus_calc"].abs().max())


# =========================================================
# 6. 读取主工况 Top 结构 ID，可选
# =========================================================

top_ids = []

if FULL_METRICS_PATH.exists():
    try:
        top_df = pd.read_excel(FULL_METRICS_PATH, sheet_name="main_rank_true_FSI_local")
        if COL_ID in top_df.columns:
            top_ids = top_df[COL_ID].dropna().astype(str).head(5).tolist()
            print("\nTop IDs from true MD FSI local:")
            print(top_ids)
    except Exception as e:
        print("\nWarning: 无法读取主工况 Top 结构，将跳过 Top-pair 插值。")
        print(e)
else:
    print("\nNo full metrics file found. Skip Top-pair interpolation.")


# =========================================================
# 7. 生成相邻 gd 真实结构之间的插值候选
# =========================================================

candidate_rows = []
counter = 1

real_sorted = real_structures.sort_values(COL_GD).reset_index(drop=True)

for i in range(len(real_sorted) - 1):
    row_a = real_sorted.iloc[i]
    row_b = real_sorted.iloc[i + 1]

    for k in range(1, N_PER_ADJACENT_SEGMENT + 1):
        alpha = k / (N_PER_ADJACENT_SEGMENT + 1)

        params = interpolate_row(row_a, row_b, alpha)

        candidate_rows.append({
            "candidate_id": f"V_ADJ_{counter:04d}",
            "candidate_type": "adjacent_gd_interpolation",
            "source_ID_A": row_a[COL_ID],
            "source_ID_B": row_b[COL_ID],
            "alpha_from_A_to_B": alpha,
            COL_DMIN: params[COL_DMIN],
            COL_DMAX: params[COL_DMAX],
            COL_DAVG: params[COL_DAVG],
            COL_GD: params[COL_GD],
            COL_GB: params[COL_GB],
            COL_T: MAIN_T,
            COL_EMAX: MAIN_EMAX,
        })

        counter += 1


# =========================================================
# 8. 生成 Top 结构之间的局部插值候选
# =========================================================

if len(top_ids) >= 2:
    top_structures = real_structures[real_structures[COL_ID].isin(top_ids)].copy()
    top_structures = top_structures.set_index(COL_ID).loc[top_ids].reset_index()

    for i in range(len(top_structures)):
        for j in range(i + 1, len(top_structures)):
            row_a = top_structures.iloc[i]
            row_b = top_structures.iloc[j]

            for alpha in TOP_PAIR_ALPHAS:
                params = interpolate_row(row_a, row_b, alpha)

                candidate_rows.append({
                    "candidate_id": f"V_TOP_{counter:04d}",
                    "candidate_type": "top_pair_interpolation",
                    "source_ID_A": row_a[COL_ID],
                    "source_ID_B": row_b[COL_ID],
                    "alpha_from_A_to_B": alpha,
                    COL_DMIN: params[COL_DMIN],
                    COL_DMAX: params[COL_DMAX],
                    COL_DAVG: params[COL_DAVG],
                    COL_GD: params[COL_GD],
                    COL_GB: params[COL_GB],
                    COL_T: MAIN_T,
                    COL_EMAX: MAIN_EMAX,
                })

                counter += 1


virtual_candidates = pd.DataFrame(candidate_rows)

if len(virtual_candidates) == 0:
    raise RuntimeError("没有生成任何虚拟候选结构。")


# =========================================================
# 9. 去重、范围检查、最近真实结构距离
# =========================================================

virtual_candidates = clean_duplicate_candidates(virtual_candidates)

virtual_candidates = add_range_flags(
    virtual_candidates,
    real_structures=real_structures,
)

virtual_candidates = add_nearest_real_distance(
    virtual_candidates,
    real_structures=real_structures,
)

# 排序：优先主 gd 范围，其次 gd 从小到大
virtual_candidates = virtual_candidates.sort_values(
    ["in_main_gd_range", COL_GD],
    ascending=[False, True]
).reset_index(drop=True)

# 重新编号，避免去重后 ID 不连续
virtual_candidates["candidate_id_old"] = virtual_candidates["candidate_id"]
virtual_candidates["candidate_id"] = [
    f"VIRT_{i+1:04d}" for i in range(len(virtual_candidates))
]

main_range_candidates = virtual_candidates[
    virtual_candidates["in_main_gd_range"]
].copy()

# 真实结构也输出成 reference candidates，方便后面画图对比
real_reference = real_structures.copy()
real_reference["candidate_id"] = ["REAL_" + str(i + 1).zfill(4) for i in range(len(real_reference))]
real_reference["candidate_type"] = "real_reference"
real_reference["source_ID_A"] = real_reference[COL_ID]
real_reference["source_ID_B"] = ""
real_reference["alpha_from_A_to_B"] = 0.0
real_reference[COL_T] = MAIN_T
real_reference[COL_EMAX] = MAIN_EMAX
real_reference["in_main_gd_range"] = (
    (real_reference[COL_GD] >= GD_MAIN_MIN) &
    (real_reference[COL_GD] <= GD_MAIN_MAX)
)


# =========================================================
# 10. 保存图：真实结构与虚拟候选分布
# =========================================================

plt.figure(figsize=(6.2, 4.8))
plt.scatter(real_structures[COL_GD], real_structures[COL_DAVG], s=60, marker="o", label="Real structures")
plt.scatter(virtual_candidates[COL_GD], virtual_candidates[COL_DAVG], s=18, alpha=0.45, label="Virtual candidates")
plt.axvspan(GD_MAIN_MIN, GD_MAIN_MAX, alpha=0.12, label="Main gd range")
plt.xlabel("gd")
plt.ylabel("Davg (nm)")
plt.title("Virtual candidates near existing design space")
plt.legend()
plt.tight_layout()
plt.savefig(FIG_DIR / "candidate_distribution_gd_Davg.png", dpi=300)
plt.close()

plt.figure(figsize=(6.2, 4.8))
plt.scatter(real_structures[COL_GD], real_structures[COL_GB], s=60, marker="o", label="Real structures")
plt.scatter(virtual_candidates[COL_GD], virtual_candidates[COL_GB], s=18, alpha=0.45, label="Virtual candidates")
plt.axvspan(GD_MAIN_MIN, GD_MAIN_MAX, alpha=0.12, label="Main gd range")
plt.xlabel("gd")
plt.ylabel("GB_frac0")
plt.title("Virtual candidates near existing design space")
plt.legend()
plt.tight_layout()
plt.savefig(FIG_DIR / "candidate_distribution_gd_GBfrac0.png", dpi=300)
plt.close()


# =========================================================
# 11. 保存 Excel
# =========================================================

summary_rows = [
    {"item": "main_temperature_K", "value": MAIN_T},
    {"item": "main_max_strain_percent", "value": MAIN_EMAX},
    {"item": "gd_main_min", "value": GD_MAIN_MIN},
    {"item": "gd_main_max", "value": GD_MAIN_MAX},
    {"item": "n_real_structures", "value": len(real_structures)},
    {"item": "n_virtual_candidates_all", "value": len(virtual_candidates)},
    {"item": "n_virtual_candidates_main_gd_range", "value": len(main_range_candidates)},
    {"item": "n_adjacent_interpolation_per_segment", "value": N_PER_ADJACENT_SEGMENT},
    {"item": "top_ids_used", "value": ", ".join(top_ids) if top_ids else "None"},
]

summary_df = pd.DataFrame(summary_rows)

with pd.ExcelWriter(OUTPUT_EXCEL, engine="openpyxl") as writer:
    summary_df.to_excel(writer, sheet_name="summary", index=False)
    real_structures.to_excel(writer, sheet_name="real_structure_library", index=False)
    real_reference.to_excel(writer, sheet_name="real_reference_candidates", index=False)
    virtual_candidates.to_excel(writer, sheet_name="virtual_candidates_all", index=False)
    main_range_candidates.to_excel(writer, sheet_name="virtual_candidates_main_gd", index=False)

    if len(top_ids) >= 2:
        top_structures.to_excel(writer, sheet_name="top_reference_structures", index=False)

print("\nVirtual candidate generation completed.")
print("All virtual candidates:", len(virtual_candidates))
print("Main gd range candidates:", len(main_range_candidates))
print("\nSaved Excel:")
print(OUTPUT_EXCEL)
print("\nSaved figures:")
print(FIG_DIR / "candidate_distribution_gd_Davg.png")
print(FIG_DIR / "candidate_distribution_gd_GBfrac0.png")

print("\nNext step:")
print("Use virtual_candidates_main_gd sheet for GRU prediction in 08_predict_virtual_candidates_gru.py")




